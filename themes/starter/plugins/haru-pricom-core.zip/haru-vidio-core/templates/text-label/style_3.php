<?php
/**
 * @package    HaruTheme/Haru Vidio
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/
extract( $atts );

?>
<div class="text-label-shortcode-wrap <?php echo $layout_type . ' ' . $el_class; ?>">
    <div class="text-label-content-wrap">
        <div class="">
        <?php if ( $title != '' ) : ?>
            <div class="text-title" style="color: <?php echo esc_attr( $title_color ); ?>; -webkit-text-stroke-color: <?php echo esc_attr( $title_color ); ?>;"><?php echo esc_html( $title ); ?></div>
        <?php endif; ?>
        <?php if ( $sub_title != '' ) : ?>
            <div class="text-sub-title"><?php echo esc_html( $sub_title ); ?></div>
        <?php endif; ?>
        </div>
    </div>
</div>