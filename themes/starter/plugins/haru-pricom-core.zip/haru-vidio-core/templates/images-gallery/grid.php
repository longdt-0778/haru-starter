<?php
/**
 * @package    HaruTheme/Haru Vidio
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/
extract( $atts );

$images      = (array)vc_param_group_parse_atts( $images );
$image_class = 'image-col-' . $columns;
// Enqueue assets
wp_enqueue_script( 'isotope', get_template_directory_uri() . '/assets/libraries/isotope/isotope.pkgd.min.js', array( 'jquery' ), '', true );
wp_enqueue_script( 'isotope-packery-mode', get_template_directory_uri() . '/assets/libraries/isotope/packery-mode.pkgd.min.js', false, true );
wp_enqueue_script( array('imagesloaded') ); // From WordPress core

?>
<div class="images-gallery-shortcode-wrap <?php echo esc_attr( $layout_type . ' ' . $el_class); ?>">
    <div class="images-list">
        <?php foreach( $images as $image ) : 
            $image_src = wp_get_attachment_url($image['image']);
            $link = '';
            if ( isset($image['link']) ) {
                $link = vc_build_link( $image['link'] );
            }
        ?>
    	<div class="image-item <?php echo $image_class . ' ' . $padding; ?>">
            <div class="slide-item">
                <img src="<?php echo esc_url($image_src); ?>" alt="<?php echo $image['title']; ?>">
                <div class="image-meta">
                    <h5 class="image-title"><?php echo esc_html( $image['title'] ); ?></h5>
                    <div class="image-actions">
                        <a href="<?php echo esc_url($image_src); ?>" class="image-gallery-popup">
                            <i class="ion ion-md-search"></i>
                        </a>
                        <?php if ( $link != '' ) : ?>
                            <a href="<?php echo esc_url($link['url']); ?>" class="image-gallery-link" target="<?php echo esc_attr( ($link['target'] != '') ? $link['target'] : '_self' ); ?>">
                                <i class="ion ion-md-add"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>