<?php
/**
 * @package    HaruTheme/Haru Vidio
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/
extract( $atts );

$services    = (array)vc_param_group_parse_atts( $services );
$services_num = count($services);
// Enqueue assets
$url_font_linea = get_template_directory_uri() . '/assets/libraries/linea/styles.css';
wp_enqueue_style( 'linea', $url_font_linea, array());

?>
<div class="services-shortcode-wrap <?php echo $layout_type . ' ' . $el_class; ?>">
    <div class="services-list columns-<?php echo esc_attr( $columns ); ?>">
        <?php foreach( $services as $service ) : 
            // Enqueue needed icon font.
            vc_icon_element_fonts_enqueue( $service['type'] );
            $iconClass = isset( $service['icon_' . $service['type']] ) ? esc_attr( $service['icon_' . $service['type']] ) : 'fa fa-adjust';
            $icon_color = $service['color'];
            if( 'custom' === $service['color'] ) {
                $icon_color = esc_attr( $service['custom_color'] );
            }

            $link      = vc_build_link( $service['link'] );
        ?>
        <div class="service-item <?php if ( $services_num <= $columns ) echo esc_attr( 'no-border' ); ?>">
            <?php if ( $link['url'] != '' ) : ?>
                <a href="<?php echo esc_attr( $link['url'] ); ?>" title="<?php echo esc_attr( $link['title'] ); ?>" target="<?php echo ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) ?>">
            <?php endif; ?>
                <div class="icon-wrap" style="color:<?php echo esc_attr( $icon_color ); ?>">
                    <span class="<?php echo esc_attr( $iconClass ); ?>"></span>
                </div>    
            <?php if ( $link['url'] != '' ) : ?>
                </a>
            <?php endif; ?>
            <h5 class="icon-title">
                <?php if ( $link['url'] != '' ) : ?>
                    <a href="<?php echo esc_attr( $link['url'] ) ?>" title="<?php echo esc_attr( $link['title'] ); ?>" target="<?php echo ( strlen( $link['target'] ) > 0 ? esc_attr( $link['target'] ) : '_self' ) ?>">
                <?php endif; ?>
                <?php echo esc_html( $service['title'] ); ?>
                <?php if ( $link['url'] != '' ) : ?>
                    </a>
                <?php endif; ?>
            </h5>
            <p class="icon-description"><?php echo wp_kses_post( $service['description'] ); ?></p>
        </div>
        <?php endforeach; ?>
    </div>
</div>