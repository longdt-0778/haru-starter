
!function($){
    $(document).ready(function() {
        $('.rwmb-footer').select2();
    });
}(jQuery);