<?php
/**
 * @package    HaruTheme/Haru Vidio
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/

// Get option
function haru_get_setting( $tab, $id, $default = null ) {
    $options = get_option($tab);
    if ( isset($options[$id]) ) {
        return $options[$id];
    }

    return $default;
}

// Process email template
function process_email_template( $replace_array, $message ) {
    foreach ( $replace_array as $key => $replace ) {
        $search = '{{' . $key . '}}';
        $message = str_replace($search, $replace, $message);
    }

    return $message;
}

/**
 * Filter the mail content type. See: https://developer.wordpress.org/reference/hooks/wp_mail_content_type/
 */
// function haru_set_html_mail_content_type() {
//     return 'text/html';
// }
// add_filter( 'wp_mail_content_type', 'haru_set_html_mail_content_type' );