<?php
/**
 * @package    HaruTheme/Haru Vidio
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/

// See: https://code.tutsplus.com/tutorials/the-wordpress-settings-api-part-5-tabbed-navigation-for-settings--wp-24971
if ( ! class_exists( 'Haru_Vidio_Settings' ) ) {
    class Haru_Vidio_Settings {

        public function __construct() {

            add_action( 'admin_menu', array( $this, 'haru_vidio_settings_menu' ), '5' );
            add_action( 'admin_init', array( $this, 'haru_vidio_register_settings' ) );

            if ( is_admin() ) {
                // Do something
            }
        }

        public function haru_vidio_settings_menu() {
            add_menu_page('Vidio Settings', 'Vidio Settings', 'administrator', 'vidio-settings', array( $this, 'haru_vidio_settings_options' ), 'dashicons-admin-generic');
        }

        function haru_vidio_settings_options() {
            // General
            $map_api_key               = haru_get_setting('vidio-general-options', 'map_api_key', 'AIzaSyBiZjBDjop9d8CDhkFORzUyZAiFcOaHe5M');

            // Email
            
            // Appointment register admin email
            $enable_appointment_register   = haru_get_setting('vidio-email-options', 'enable_appointment_register', '');
            $notify_email_appointment      = haru_get_setting('vidio-email-options', 'notify_email_appointment', '');
            $appointment_register_subject  = haru_get_setting('vidio-email-options', 'appointment_register_subject', '[{{site_name}}] New appointment at salon {{salon_name}} received');
            $appointment_register_header   = haru_get_setting('vidio-email-options', 'appointment_register_header', 'From: {{first_name}} {{last_name}} <{{email}}>');
            $appointment_register_messsage = haru_get_setting('vidio-email-options', 'appointment_register_messsage', '<strong>{{first_name}} {{last_name}}</strong> has just booked new appointment at salon <strong>{{salon_name}}</strong>');

            // Appointment register customer email
            $enable_appointment_register_customer   = haru_get_setting('vidio-email-options', 'enable_appointment_register_customer', '');
            $appointment_register_customer_subject  = haru_get_setting('vidio-email-options', 'appointment_register_customer_subject', '[{{site_name}}] Appointment booking at salon [{{salon_name}}]');
            $appointment_register_customer_header   = haru_get_setting('vidio-email-options', 'appointment_register_customer_header', 'From: {{site_name}} <no-reply@harutheme.com>');
            $appointment_register_customer_messsage = haru_get_setting('vidio-email-options', 'appointment_register_customer_messsage', 'You has just booked an appointment at salon {{salon_name}} with barber <strong>{{barber_name}}');

            // Appointment approved customer email
            $enable_appointment_approved_customer   = haru_get_setting('vidio-email-options', 'enable_appointment_approved_customer', '');
            $appointment_approved_customer_subject  = haru_get_setting('vidio-email-options', 'appointment_approved_customer_subject', '[{{site_name}}] Appointment booking at salon [{{salon_name}}] has been approved');
            $appointment_approved_customer_header   = haru_get_setting('vidio-email-options', 'appointment_approved_customer_header', 'From: {{site_name}} <no-reply@harutheme.com>');
            $appointment_approved_customer_messsage = haru_get_setting('vidio-email-options', 'appointment_approved_customer_messsage', 'Your appointment at salon {{salon_name}} with barber <strong>{{barber_name}} has been approved.');
        ?>
            <!-- Create a header in the default WordPress 'wrap' container -->
            <div class="wrap">
                <?php settings_errors(); ?>

                <?php
                    $active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'general-options';
                ?>

                <h2 class="nav-tab-wrapper">
                    <a href="?page=vidio-settings&tab=general-options" class="nav-tab <?php echo $active_tab == 'general-options' ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__( 'General', 'haru-vidio' ); ?></a>
                    <a href="?page=vidio-settings&tab=email-options" class="nav-tab <?php echo $active_tab == 'email-options' ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__( 'Emails', 'haru-vidio' ); ?></a>
                </h2>

                <form method="post" action="options.php">
                    <?php if ( $active_tab == 'general-options' ) : ?>
                        <?php settings_fields( 'vidio-general-options' ); ?>
                        <?php do_settings_sections( 'vidio-general-options' ); ?>
                        <table class="form-table">

                            <tr valign="top">
                                <th scope="row"><?php echo esc_html__( 'Google Map API key', 'haru-vidio' );?></th>
                                <td>
                                    <input type="text" name="vidio-general-options[map_api_key]" class="map-api-key" value="<?php echo esc_attr($map_api_key); ?>" />
                                </td>
                            </tr>

                        </table>
                    <?php else : ?>
                        <!-- Email Options Tab -->
                        <?php settings_fields( 'vidio-email-options' ); ?>
                        <?php do_settings_sections( 'vidio-email-options' ); ?>
                        <?php
                            $active_section = isset( $_GET[ 'section' ] ) ? $_GET[ 'section' ] : 'appointment-register';
                        ?>
                        <h4 class="nav-section-wrapper">
                            <a href="?page=vidio-settings&tab=email-options&section=appointment-register" class="nav-section <?php echo $active_section == 'appointment-register' ? 'nav-section-active' : ''; ?>"><?php echo esc_html__( 'New Appointment Admin', 'haru-vidio' ); ?></a>
                            <a href="?page=vidio-settings&tab=email-options&section=appointment-register-customer" class="nav-section <?php echo $active_section == 'appointment-register-customer' ? 'nav-section-active' : ''; ?>"><?php echo esc_html__( 'New Appointment Customer', 'haru-vidio' ); ?></a>
                            <a href="?page=vidio-settings&tab=email-options&section=appointment-approved-customer" class="nav-section <?php echo $active_section == 'appointment-approved-customer' ? 'nav-section-active' : ''; ?>"><?php echo esc_html__( 'Approved Appointment Customer', 'haru-vidio' ); ?></a>
                        </h4>
                        <table class="form-table email-options">
                            <!-- Appointment Register Admin -->
                            <tr valign="top" class="appointment-register">
                                <th scope="row"><?php echo esc_html__( 'Enable', 'haru-vidio' );?></th>
                                <td>
                                    <input type="checkbox" name="vidio-email-options[enable_appointment_register]" value="1" <?php checked( $enable_appointment_register, 1); ?> />
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-register">
                                <th scope="row"><?php echo esc_html__( 'Email Variables', 'haru-vidio' );?></th>
                                <td>
                                    <p class="variables-description"><?php echo esc_html__( 'You can use these variables in email template:' ); ?></p>
                                    <ul class="variables-list">
                                        <li>{{first_name}}</li>
                                        <li>{{last_name}}</li>
                                        <li>{{email}}</li>
                                        <li>{{phone}}</li>
                                        <li>{{message}}</li>
                                        <li>{{appointment_start}}</li>
                                        <li>{{appointment_end}}</li>
                                        <li>{{salon_name}}</li>
                                        <li>{{barber_name}}</li>
                                        <li>{{site_name}}</li>
                                    </ul>
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-register">
                                <th scope="row"><?php echo esc_html__( 'Email notification', 'haru-vidio' );?></th>
                                <td>
                                    <input type="email" name="vidio-email-options[notify_email_appointment]" value="<?php echo esc_attr( $notify_email_appointment ); ?>" placeholder="email@domain.com" />
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-register">
                                <th scope="row"><?php echo esc_html__( 'Subject', 'haru-vidio' );?></th>
                                <td>
                                    <input type="text" name="vidio-email-options[appointment_register_subject]" value="<?php echo esc_attr( $appointment_register_subject ); ?>" placeholder="[{{site_name}}] New appointment for salon {{salon_name}} received" />
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-register">
                                <th scope="row"><?php echo esc_html__( 'Header', 'haru-vidio' );?></th>
                                <td>
                                    <input type="text" name="vidio-email-options[appointment_register_header]" value="<?php echo esc_attr( $appointment_register_header ); ?>" placeholder="From: {{first_name}} {{last_name}} <{{email}}>" />
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-register">
                                <th scope="row"><?php echo esc_html__( 'Email Content', 'haru-vidio' );?></th>
                                <td>
                                    <?php 
                                        $settings = array( 
                                            'textarea_name' => 'vidio-email-options[appointment_register_messsage]',
                                            'textarea_rows' => 10 
                                        );
                                        wp_editor( $appointment_register_messsage, 'appointment_register_messsage', $settings ); 
                                    ?>
                                </td>
                            </tr>
                            <!-- Appointment Register Customer -->
                            <tr valign="top" class="appointment-register-customer">
                                <th scope="row"><?php echo esc_html__( 'Enable', 'haru-vidio' );?></th>
                                <td>
                                    <input type="checkbox" name="vidio-email-options[enable_appointment_register_customer]" value="1" <?php checked( $enable_appointment_register_customer, 1); ?> />
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-register-customer">
                                <th scope="row"><?php echo esc_html__( 'Email Variables', 'haru-vidio' );?></th>
                                <td>
                                    <p class="variables-description"><?php echo esc_html__( 'You can use these variables in email template:' ); ?></p>
                                    <ul class="variables-list">
                                        <li>{{first_name}}</li>
                                        <li>{{last_name}}</li>
                                        <li>{{email}}</li>
                                        <li>{{phone}}</li>
                                        <li>{{message}}</li>
                                        <li>{{appointment_start}}</li>
                                        <li>{{appointment_end}}</li>
                                        <li>{{salon_name}}</li>
                                        <li>{{barber_name}}</li>
                                        <li>{{site_name}}</li>
                                    </ul>
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-register-customer">
                                <th scope="row"><?php echo esc_html__( 'Subject', 'haru-vidio' );?></th>
                                <td>
                                    <input type="text" name="vidio-email-options[appointment_register_customer_subject]" value="<?php echo esc_attr( $appointment_register_customer_subject ); ?>" placeholder="[{{site_name}}] Appointment booking at salon [{{salon_name}}]"/>
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-register-customer">
                                <th scope="row"><?php echo esc_html__( 'Header', 'haru-vidio' );?></th>
                                <td>
                                    <input type="text" name="vidio-email-options[appointment_register_customer_header]" value="<?php echo esc_attr( $appointment_register_customer_header ); ?>" placeholder="From: No-Reply <no-reply@domain.com>" />
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-register-customer">
                                <th scope="row"><?php echo esc_html__( 'Email Content', 'haru-vidio' );?></th>
                                <td>
                                    <?php 
                                        $settings = array( 
                                            'textarea_name' => 'vidio-email-options[appointment_register_customer_messsage]',
                                            'textarea_rows' => 10 
                                        );
                                        wp_editor( $appointment_register_customer_messsage, 'appointment_register_customer_messsage', $settings ); 
                                    ?>
                                </td>
                            </tr>
                            <!-- Appointment Approved Customer -->
                            <tr valign="top" class="appointment-approved-customer">
                                <th scope="row"><?php echo esc_html__( 'Enable', 'haru-vidio' );?></th>
                                <td>
                                    <input type="checkbox" name="vidio-email-options[enable_appointment_approved_customer]" value="1" <?php checked( $enable_appointment_approved_customer, 1); ?> />
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-approved-customer">
                                <th scope="row"><?php echo esc_html__( 'Email Variables', 'haru-vidio' );?></th>
                                <td>
                                    <p class="variables-description"><?php echo esc_html__( 'You can use these variables in email template:' ); ?></p>
                                    <ul class="variables-list">
                                        <li>{{first_name}}</li>
                                        <li>{{last_name}}</li>
                                        <li>{{email}}</li>
                                        <li>{{phone}}</li>
                                        <li>{{message}}</li>
                                        <li>{{appointment_start}}</li>
                                        <li>{{appointment_end}}</li>
                                        <li>{{salon_name}}</li>
                                        <li>{{barber_name}}</li>
                                        <li>{{site_name}}</li>
                                    </ul>
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-approved-customer">
                                <th scope="row"><?php echo esc_html__( 'Subject', 'haru-vidio' );?></th>
                                <td>
                                    <input type="text" name="vidio-email-options[appointment_approved_customer_subject]" value="<?php echo esc_attr( $appointment_approved_customer_subject ); ?>" placeholder="[{{site_name}}] Appointment booking at salon [{{salon_name}}] has been approved"/>
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-approved-customer">
                                <th scope="row"><?php echo esc_html__( 'Header', 'haru-vidio' );?></th>
                                <td>
                                    <input type="text" name="vidio-email-options[appointment_approved_customer_header]" value="<?php echo esc_attr( $appointment_approved_customer_header ); ?>" placeholder="From: No-Reply <no-reply@domain.com>" />
                                </td>
                            </tr>
                            <tr valign="top" class="appointment-approved-customer">
                                <th scope="row"><?php echo esc_html__( 'Email Content', 'haru-vidio' );?></th>
                                <td>
                                    <?php 
                                        $settings = array( 
                                            'textarea_name' => 'vidio-email-options[appointment_approved_customer_messsage]',
                                            'textarea_rows' => 10 
                                        );
                                        wp_editor( $appointment_approved_customer_messsage, 'appointment_approved_customer_messsage', $settings ); 
                                    ?>
                                </td>
                            </tr>
                        </table>
                        <script>
                            jQuery(document).ready(function($) {
                                var show_class = '<?php echo esc_js($active_section); ?>';
                                $('.form-table.email-options').find('tr').not('.' + show_class).hide();
                            });
                        </script>
                    <?php endif; ?>

                    <?php submit_button(); ?>

                </form>

            </div><?php
        }

        function haru_vidio_register_settings() {
            // General settings
            register_setting( 'vidio-general-options', 'vidio-general-options' );
            // Email settings
            register_setting( 'vidio-email-options', 'vidio-email-options' );
        }

    }

    new Haru_Vidio_Settings;
}