<?php
/**
 * @package    HaruTheme/Haru Vidio
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/

if( ! class_exists( 'Haru_Vidio' ) ) {
    class Haru_Vidio {
        static $instance;

        public function __construct() {
            $this->haru_vidio_includes_files();
        }

        public function haru_vidio_includes_files() {
            // require_once( PLUGIN_HARU_VIDIO_CORE_DIR . 'includes/vidio/vidio-functions.php');
            // require_once( PLUGIN_HARU_VIDIO_CORE_DIR . 'includes/vidio/class-vidio-settings.php');
        }
    }

    $haru_vidio = new Haru_Vidio;
}