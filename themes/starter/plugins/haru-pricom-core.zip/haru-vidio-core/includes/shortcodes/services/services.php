<?php
/**
 * @package    HaruTheme/Haru Vidio
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/

if ( ! defined( 'ABSPATH' ) ) die( '-1' );

if ( ! class_exists('Haru_Framework_Shortcode_Services') ) {
    class Haru_Framework_Shortcode_Services {
        function __construct() {
            add_shortcode( 'haru_services', array($this, 'haru_services_shortcode') );
            add_action( 'vc_before_init', array($this, 'haru_services_vc_map') );
        }

        function haru_services_shortcode($atts) {
            $atts = vc_map_get_attributes( 'haru_services', $atts );
            $services = $layout_type = $columns = $el_class = $haru_animation = $css_animation = $duration = $delay = $styles_animation = '';
            extract(shortcode_atts(array(
                'services'         => '',
                'layout_type'      => 'style_1',
                'columns'          => '',
                'el_class'         => '',
                'css_animation'    => '',
                'duration'         => '',
                'delay'            => '',
            ), $atts));

            $haru_animation   = HARU_VidioCore_Shortcodes::haru_get_css_animation($css_animation);
            $styles_animation = HARU_VidioCore_Shortcodes::haru_get_style_animation($duration, $delay);

            ob_start();
            
            ?>
            
            <div class="<?php echo esc_attr($haru_animation . ' ' . $styles_animation); ?>">
                <?php echo haru_get_template('services/'. $layout_type . '.php', array('atts' => $atts), '', '' ); ?>
            </div>
            
        <?php
            $content =  ob_get_clean();
            return $content;         
        }

        function haru_services_vc_map() {
            vc_map(
                array(
                    'name'        => esc_html__( 'Haru Services', 'haru-vidio' ),
                    'base'        => 'haru_services',
                    'icon'        => 'fa fa-info haru-vc-icon',
                    'description' => esc_html__( 'Display Services with Icon', 'haru-vidio' ),
                    'category'    => HARU_VIDIO_CORE_SHORTCODE_CATEGORY,
                    'params'      => array(
                        array(
                            'type'        => 'param_group',
                            'heading'     => esc_html__( 'Services', 'haru-vidio' ),
                            'param_name'  => 'services',
                            'description' => esc_html__( 'Enter services.', 'haru-vidio' ),
                            'value'       => urlencode( json_encode( array(
                                array(
                                    'type' => esc_html__( 'Linea', 'haru-vidio' ),
                                    'iconpicker' => '',
                                    'color' => '',
                                    'custom_color' => '',
                                    'title' => '',
                                    'description' => '',
                                    'link' => '',
                                ),
                                array(
                                    'type'  => esc_html__( 'Linea', 'haru-vidio' ),
                                    'iconpicker' => '',
                                    'color' => '',
                                    'custom_color' => '',
                                    'title' => '',
                                    'description' => '',
                                    'link' => '',
                                ),
                                array(
                                    'type'  => esc_html__( 'Linea', 'haru-vidio' ),
                                    'iconpicker' => '',
                                    'color' => '',
                                    'custom_color' => '',
                                    'title' => '',
                                    'description' => '',
                                    'link' => '',
                                ),
                            ) ) ),
                            'params' => array(
                                array(
                                    'type'    => 'dropdown',
                                    'heading' => esc_html__( 'Icon library', 'haru-vidio' ),
                                    'value'   => array(
                                        esc_html__( 'Font Awesome', 'haru-vidio' ) => 'fontawesome',
                                        esc_html__( 'Open Iconic', 'haru-vidio' )  => 'openiconic',
                                        esc_html__( 'Typicons', 'haru-vidio' )     => 'typicons',
                                        esc_html__( 'Entypo', 'haru-vidio' )       => 'entypo',
                                        esc_html__( 'Linecons', 'haru-vidio' )     => 'linecons',
                                        esc_html__( 'Linea', 'haru-vidio' )      => 'linea',
                                    ),
                                    'admin_label' => true,
                                    'param_name'  => 'type',
                                    'description' => esc_html__( 'Select icon library.', 'haru-vidio' ),
                                    'dependency' => array(
                                        'element' => 'layout_type',
                                        'value'   => array('style_1')
                                    ),
                                ),
                                array(
                                    'type'       => 'iconpicker',
                                    'heading'    => esc_html__( 'Icon', 'haru-vidio' ),
                                    'param_name' => 'icon_fontawesome',
                                    'value'      => 'fa fa-adjust', // default value to backend editor admin_label
                                    'settings'   => array(
                                        'emptyIcon'    => false,
                                        // default true, display an "EMPTY" icon?
                                        'iconsPerPage' => 4000,
                                        // default 100, how many icons per/page to display, we use (big number) to display all icons in single page
                                    ),
                                    'dependency' => array(
                                        'element' => 'type',
                                        'value'   => 'fontawesome',
                                    ),
                                    'description' => esc_html__( 'Select icon from library.', 'haru-vidio' ),
                                ),
                                array(
                                    'type'       => 'iconpicker',
                                    'heading'    => esc_html__( 'Icon', 'haru-vidio' ),
                                    'param_name' => 'icon_openiconic',
                                    'value'      => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
                                    'settings'   => array(
                                        'emptyIcon'    => false, // default true, display an "EMPTY" icon?
                                        'type'         => 'openiconic',
                                        'iconsPerPage' => 4000, // default 100, how many icons per/page to display
                                    ),
                                    'dependency' => array(
                                        'element' => 'type',
                                        'value'   => 'openiconic',
                                    ),
                                    'description' => esc_html__( 'Select icon from library.', 'haru-vidio' ),
                                ),
                                array(
                                    'type'       => 'iconpicker',
                                    'heading'    => esc_html__( 'Icon', 'haru-vidio' ),
                                    'param_name' => 'icon_typicons',
                                    'value'      => 'typcn typcn-adjust-brightness', // default value to backend editor admin_label
                                    'settings'   => array(
                                        'emptyIcon'    => false, // default true, display an "EMPTY" icon?
                                        'type'         => 'typicons',
                                        'iconsPerPage' => 4000, // default 100, how many icons per/page to display
                                    ),
                                    'dependency' => array(
                                        'element' => 'type',
                                        'value'   => 'typicons',
                                    ),
                                    'description' => esc_html__( 'Select icon from library.', 'haru-vidio' ),
                                ),
                                array(
                                    'type'       => 'iconpicker',
                                    'heading'    => esc_html__( 'Icon', 'haru-vidio' ),
                                    'param_name' => 'icon_entypo',
                                    'value'      => 'entypo-icon entypo-icon-note', // default value to backend editor admin_label
                                    'settings'   => array(
                                        'emptyIcon'    => false, // default true, display an "EMPTY" icon?
                                        'type'         => 'entypo',
                                        'iconsPerPage' => 4000, // default 100, how many icons per/page to display
                                    ),
                                    'dependency' => array(
                                        'element' => 'type',
                                        'value'   => 'entypo',
                                    ),
                                ),
                                array(
                                    'type'       => 'iconpicker',
                                    'heading'    => esc_html__( 'Icon', 'haru-vidio' ),
                                    'param_name' => 'icon_linecons',
                                    'value'      => 'vc_li vc_li-heart', // default value to backend editor admin_label
                                    'settings'   => array(
                                        'emptyIcon'    => false, // default true, display an "EMPTY" icon?
                                        'type'         => 'linecons',
                                        'iconsPerPage' => 4000, // default 100, how many icons per/page to display
                                    ),
                                    'dependency' => array(
                                        'element' => 'type',
                                        'value'   => 'linecons',
                                    ),
                                    'description' => esc_html__( 'Select icon from library.', 'haru-vidio' ),
                                ),

                                // Add new font: https://themeinjection.ticksy.com/ticket/841239/
                                array(
                                    'type'       => 'iconpicker',
                                    'heading'    => esc_html__( 'Icon', 'haru-vidio' ),
                                    'param_name' => 'icon_linea',
                                    'value'      => 'icon icon-basic-compass', // default value to backend editor admin_label
                                    'settings'   => array(
                                        'emptyIcon'    => false, // default true, display an "EMPTY" icon?
                                        'type'         => 'linea',
                                        'iconsPerPage' => 4000, // default 100, how many icons per/page to display
                                    ),
                                    'dependency' => array(
                                        'element' => 'type',
                                        'value'   => 'linea',
                                    ),
                                    'description' => esc_html__( 'Select icon from library.', 'haru-vidio' ),
                                ),
                                array(
                                    'type'               => 'dropdown',
                                    'heading'            => esc_html__( 'Icon color', 'haru-vidio' ),
                                    'param_name'         => 'color',
                                    'value'              => array_merge( getVcShared( 'colors' ), array( esc_html__( 'Custom color', 'haru-vidio' ) => 'custom' ) ),
                                    'description'        => esc_html__( 'Select icon color.', 'haru-vidio' ),
                                    'param_holder_class' => 'vc_colored-dropdown',
                                    'dependency' => array(
                                        'element' => 'layout_type',
                                        'value'   => array('style_1')
                                    ),
                                ),
                                array(
                                    'type'        => 'colorpicker',
                                    'heading'     => esc_html__( 'Custom color', 'haru-vidio' ),
                                    'param_name'  => 'custom_color',
                                    'description' => esc_html__( 'Select custom icon color.', 'haru-vidio' ),
                                    'dependency'  => array(
                                        'element' => 'color',
                                        'value'   => 'custom',
                                        'dependency' => array(
                                            'element' => 'layout_type',
                                            'value'   => array('style_1')
                                        ),
                                    ),
                                ),
                                // array(
                                //     'type'        => 'attach_image',
                                //     'heading'     => esc_html__( 'Image', 'haru-vidio' ),
                                //     'param_name'  => 'icon_image',
                                //     'description' => esc_html__( 'Please select icon box\' image.', 'haru-vidio' ),
                                //     'admin_label' => true,
                                //     'dependency' => array(
                                //         'element' => 'layout_type',
                                //         'value'   => array('style_2')
                                //     ),
                                // ),
                                // array(
                                //     'type'        => 'textfield',
                                //     'heading'     => esc_html__( 'Icon Text', 'haru-vidio' ),
                                //     'param_name'  => 'icon_text',
                                //     'admin_label' => true,
                                //     'dependency' => array(
                                //         'element' => 'layout_type',
                                //         'value'   => array('style_4')
                                //     ),
                                // ),
                                array(
                                    'type'        => 'textfield',
                                    'heading'     => esc_html__( 'Title', 'haru-vidio' ),
                                    'param_name'  => 'title',
                                    'admin_label' => true
                                ),
                                array(
                                    'type'        => 'textarea',
                                    'heading'     => esc_html__( 'Description', 'haru-vidio' ),
                                    'param_name'  => 'description',
                                    'admin_label' => false,
                                    'dependency' => array(
                                        'element' => 'layout_type',
                                        'value'   => array('style_1', 'style_2', 'style_3','style_4')
                                    ),
                                ),
                                array(
                                    'type'        => 'vc_link',
                                    'heading'     => esc_html__( 'Link', 'haru-vidio' ),
                                    'param_name'  => 'link',
                                    'admin_label' => false
                                ),
                            ),
                        ),
                        array(
                            'type'       => 'dropdown',
                            'heading'    => esc_html__( 'Layout Style', 'haru-vidio' ),
                            'param_name' => 'layout_type',
                            'admin_label' => true,
                            'value'      => array(
                                esc_html__( 'Style 1 (Grid)', 'haru-vidio' )  => 'style_1',
                            ),
                            'edit_field_class' => 'vc_col-sm-6 vc_column vc_column-with-padding',
                        ),
                        array( 
                            'param_name'       => 'columns', 
                            'heading'          => esc_html__( 'Columns', 'haru-vidio' ),
                            'type'             => 'dropdown',
                            'value'            => array( 2, 3, 4, 5, 6 ),
                            'admin_label'      => true,
                            'edit_field_class' => 'vc_col-sm-6 vc_column vc_column-with-padding',
                        ),
                        Haru_VidioCore_Shortcodes::add_css_animation(),
                        Haru_VidioCore_Shortcodes::add_duration_animation(),
                        Haru_VidioCore_Shortcodes::add_delay_animation(),
                        Haru_VidioCore_Shortcodes::add_el_class()
                    )
                )
            );
        }
    }

    new Haru_Framework_Shortcode_Services();
}