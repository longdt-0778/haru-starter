<?php
/**
 * @package    HaruTheme/Haru Vidio
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/

if ( ! defined( 'ABSPATH' ) ) die( '-1' );

if ( ! class_exists('Haru_Framework_Shortcode_Testimonial') ) {
    class Haru_Framework_Shortcode_Testimonial {
        function __construct() {
            add_shortcode( 'haru_testimonial', array( $this, 'haru_testimonial_shortcode' ) );
            add_action( 'vc_before_init', array($this, 'haru_testimonial_vc_map') );
        }

        function haru_testimonial_shortcode($atts) {
            $atts        = vc_map_get_attributes( 'haru_testimonial', $atts );
            $layout_type = $data_source = $category = $testimonial_ids = $orderby = $order = $columns = $autoplay = $slide_duration = $el_class = $haru_animation = $css_animation = $duration = $delay = $styles_animation = '';
            extract(shortcode_atts(array(
                'layout_type'     => 'carousel',
                'data_source'     => '',
                'category'        => '',
                'testimonial_ids' => '',
                'orderby'         => 'date',
                'order'           => 'DESC',
                'columns'         => '1',
                'autoplay'        => 'true',
                'slide_duration'  => '6000',
                'el_class'        => '',
                'css_animation'   => '',
                'duration'        => '',
                'delay'           => '',
                'excerpt_length'  => '',
            ), $atts));

            $haru_animation   = HARU_VidioCore_Shortcodes::haru_get_css_animation($css_animation);
            $styles_animation = HARU_VidioCore_Shortcodes::haru_get_style_animation($duration, $delay);

            ob_start();
        ?>
        
        <div class="<?php echo esc_attr($haru_animation . ' ' . $styles_animation); ?>">
            <?php echo haru_get_template('posttypes/testimonial/'. $layout_type . '.php', array('atts' => $atts), '', '' ); ?>
        </div>  
        
        <?php
            wp_reset_postdata();
            $content =  ob_get_clean();
            return $content;
        }

        function haru_testimonial_vc_map() {
            vc_map(
                array(
                    'name'        => esc_html__( 'Haru Testimonial', 'haru-vidio' ),
                    'base'        => 'haru_testimonial',
                    'icon'        => 'fa fa-comments haru-vc-icon',
                    'description' => esc_html__( 'Display client testimonials', 'haru-vidio' ),
                    'category'    => HARU_VIDIO_CORE_SHORTCODE_CATEGORY,
                    'params'      => array(
                        array(
                            'param_name' => 'layout_type',
                            'type'       => 'dropdown',
                            'heading'    => esc_html__( 'Layout Style', 'haru-vidio' ),
                            'value'      => array(
                                esc_html__( 'Carousel', 'haru-vidio' )     => 'carousel',
                                esc_html__( 'Carousel 2 (Background Color)', 'haru-vidio' )   => 'carousel_2',
                                esc_html__( 'Carousel 3 (Background White)', 'haru-vidio' )   => 'carousel_3',
                            ),
                        ),
                        array(
                            'param_name'  => 'data_source',
                            'type'        => 'dropdown',
                            'heading'     => esc_html__( 'Source', 'haru-vidio' ),
                            'admin_label' => true,
                            'value'       => array(
                                esc_html__( 'From Category', 'haru-vidio' )        => '',
                                esc_html__( 'From Testimonial IDs', 'haru-vidio' ) => 'list_id'
                            )
                        ),
                        array(
                            'param_name'  => 'category',
                            'type'        => 'haru_testimonial_categories',
                            'heading'     => esc_html__( 'Testimonial Category', 'haru-vidio' ),
                            'admin_label' => true,
                            'dependency'  => array(
                                'element' => 'data_source', 
                                'value'   => array('')
                            ),
                        ),
                        array(
                            'param_name' => 'testimonial_ids',
                            'type'       => 'haru_testimonial_list',
                            'heading'    => esc_html__( 'Select Testimonial', 'haru-vidio' ),
                            'dependency' => array(
                                'element' => 'data_source', 
                                'value'   => array('list_id')
                            )
                        ),
                        array(
                            'param_name' => 'orderby',
                            'type'       => 'dropdown',
                            'heading'    => esc_html__( 'Order by', 'haru-vidio' ),
                            'value'      => array(
                                esc_html__( 'Date', 'haru-vidio' )                  => 'date',
                                esc_html__( 'Order by post ID', 'haru-vidio' )      => 'ID',
                                esc_html__( 'Author', 'haru-vidio' )                => 'author',
                                esc_html__( 'Title', 'haru-vidio' )                 => 'title',
                                esc_html__( 'Last modified date', 'haru-vidio' )    => 'modified',
                                esc_html__( 'Post/page parent ID', 'haru-vidio' )   => 'parent',
                                esc_html__( 'Number of comments', 'haru-vidio' )    => 'comment_count',
                                esc_html__( 'Random order', 'haru-vidio' )          => 'rand',
                            ),
                            'description'        => esc_html__( 'Select order type.', 'haru-vidio' ),
                            'edit_field_class' => 'vc_col-sm-6 vc_column vc_column-with-padding',
                        ),
                        array(
                            'param_name' => 'order',
                            'type'       => 'dropdown',
                            'heading'    => esc_html__( 'Order Post Date By', 'haru-vidio' ),
                            'value'      => array(
                                esc_html__( 'Descending', 'haru-vidio' ) => 'DESC', 
                                esc_html__( 'Ascending', 'haru-vidio' )  => 'ASC'
                            )
                        ),
                        array(
                            'param_name'       => 'excerpt_length',
                            'type'             => 'textfield',
                            'heading'          => esc_html__( 'Excerpt length', 'haru-vidio' ),
                            'std'              => '20'
                        ),
                        array(
                            'param_name'  => 'columns', 
                            'heading'     => esc_html__( 'Number of Columns', 'haru-vidio' ), 
                            'type'        => 'dropdown', 
                            'admin_label' => true, 
                            'value'       => array(
                                esc_html__( '1', 'haru_vidio' ) => '1',
                                esc_html__( '2', 'haru-vidio' ) => '2',
                                esc_html__( '3', 'haru-vidio' ) => '3', 
                                esc_html__( '4', 'haru-vidio' ) => '4', 
                                esc_html__( '5', 'haru-vidio' ) => '5', 
                            ),
                            'group'       => esc_html__( 'Slide Settings', 'haru-vidio' ),
                        ),
                        array(
                            'param_name' => 'autoplay',
                            'type'       => 'dropdown',
                            'heading'    => esc_html__( 'AutoPlay', 'haru-vidio' ),
                            'value'      => array(
                                esc_html__( 'Yes', 'haru-vidio') => 'true', 
                                esc_html__( 'No', 'haru-vidio')  => 'false'
                            ),
                            'group'       => esc_html__( 'Slide Settings', 'haru-vidio' ), 
                        ),
                        array(
                            'param_name'       => 'slide_duration',
                            'type'             => 'textfield',
                            'heading'          => esc_html__( 'Slide Duration (ms)', 'haru-vidio' ),
                            'std'             => '6000',
                            'admin_label'      => true,
                            'group'       => esc_html__( 'Slide Settings', 'haru-vidio' ),
                        ),
                        Haru_VidioCore_Shortcodes::add_css_animation(),
                        Haru_VidioCore_Shortcodes::add_duration_animation(),
                        Haru_VidioCore_Shortcodes::add_delay_animation(),
                        Haru_VidioCore_Shortcodes::add_el_class()
                    )
                )
            );
        }
    }

    new Haru_Framework_Shortcode_Testimonial();
}