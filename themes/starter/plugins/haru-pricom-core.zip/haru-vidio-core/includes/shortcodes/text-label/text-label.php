<?php
/**
 * @package    HaruTheme/Haru Vidio
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/

if ( ! defined( 'ABSPATH' ) ) die( '-1' );

if ( ! class_exists('Haru_Framework_Shortcode_Text_Label') ) {
    class Haru_Framework_Shortcode_Text_Label {
        function __construct() {
            add_shortcode( 'haru_text_label', array($this, 'haru_text_label_shortcode') );
            add_action( 'vc_before_init', array($this, 'haru_text_label_vc_map') );
        }

        function haru_text_label_shortcode($atts) {
            $atts        = vc_map_get_attributes( 'haru_text_label', $atts );
            $layout_type = $title = $sub_title = $title_color = $css = $el_class = $haru_animation = $css_animation = $duration = $delay = $styles_animation = '';
            extract(shortcode_atts(array(
                'layout_type'       => 'style_1',
                'title'             => '',
                'sub_title'         => '',
                'title_color'         => '',
                'css'               => '',
                'el_class'          => '',
                'css_animation'     => '',
                'duration'          => '',
                'delay'             => '',
            ), $atts)); 

            $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), 'haru_text_label', $atts );

            $haru_animation   = HARU_VidioCore_Shortcodes::haru_get_css_animation($css_animation);
            $styles_animation = HARU_VidioCore_Shortcodes::haru_get_style_animation($duration, $delay);

            ob_start();

            ?>
            <?php if ( $title != '' ) : ?>
            <div class="<?php echo esc_attr($css_class . ' ' . $haru_animation . ' ' . $styles_animation); ?>">
                <?php echo haru_get_template('text-label/'. $layout_type . '.php', array('atts' => $atts), '', '' ); ?>
            </div>
            <?php else : ?>
                <div class="text-label-not-select"><?php echo esc_html__( 'Please set title for Text Label!', 'haru-vidio' ); ?></div>
            <?php endif; ?>
        <?php
            $content =  ob_get_clean();
            return $content;         
        }

        function haru_text_label_vc_map() {
            vc_map(
                array(
                    'name'        => esc_html__( 'Haru Text Label', 'haru-vidio' ),
                    'base'        => 'haru_text_label',
                    'icon'        => 'fa fa-windows haru-vc-icon',
                    'description' => esc_html__( 'Display Text Label', 'haru-vidio' ),
                    'category'    => HARU_VIDIO_CORE_SHORTCODE_CATEGORY,
                    'params'      => array(
                        array(
                            'type'       => 'dropdown',
                            'heading'    => esc_html__( 'Layout Style', 'haru-vidio' ),
                            'param_name' => 'layout_type',
                            'value'      => array(
                                esc_html__( 'Style 1 (About Home 1)', 'haru-vidio' )            => 'style_1',
                                esc_html__( 'Style 2 (About Home 4)', 'haru-vidio' )            => 'style_2',
                                esc_html__( 'Style 3 (Onepage Number)', 'haru-vidio' )          => 'style_3',
                                esc_html__( 'Style 3 (Freelancer Title)', 'haru-vidio' )        => 'style_4',
                            ),
                        ),
                        array(
                            'type'        => 'textfield',
                            'heading'     => esc_html__( 'Title', 'haru-vidio' ),
                            'param_name'  => 'title',
                            'admin_label' => true,
                        ),
                        array(
                            'type'        => 'textfield',
                            'heading'     => esc_html__( 'Sub Title', 'haru-vidio' ),
                            'param_name'  => 'sub_title',
                            'admin_label' => true,
                            'dependency'  => array(
                                'element' => 'layout_type',
                                'value'   => array('style_5'),
                            ),
                        ),
                        array(
                            'type'        => 'colorpicker',
                            'heading'     => esc_html__( 'Title color', 'haru-vidio' ),
                            'param_name'  => 'title_color',
                            'description' => esc_html__( 'Select custom title color.', 'haru-vidio' ),
                            'dependency' => array(
                                'element' => 'layout_type',
                                'value'   => array('style_3', 'style_4')
                            ),
                        ),
                        array(
                            'type'       => 'css_editor',
                            'heading'    => esc_html__( 'CSS box', 'haru-vidio' ),
                            'param_name' => 'css',
                            'group'      => esc_html__( 'Design Options', 'haru-vidio' ),
                        ),
                        Haru_VidioCore_Shortcodes::add_css_animation(),
                        Haru_VidioCore_Shortcodes::add_duration_animation(),
                        Haru_VidioCore_Shortcodes::add_delay_animation(),
                        Haru_VidioCore_Shortcodes::add_el_class()
                    )
                )
            );
        }
    }

    new Haru_Framework_Shortcode_Text_Label();
}