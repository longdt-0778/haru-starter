<?php
/**
 * @package    HaruTheme/Haru Vidi
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/

?>
<div class="video-image1 player-popup">
    <div class="video-icon">
        <a href="javascript:;" 
            class="video-player-popup" 
            data-id="<?php echo esc_attr( the_ID() ); ?>"
        >
        </a>
    </div>
</div>    

