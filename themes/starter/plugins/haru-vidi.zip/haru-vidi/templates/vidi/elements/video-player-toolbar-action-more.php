<?php
/**
 * @package    HaruTheme/Haru Vidi
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/

?>

<div class="toolbar-action toolbar-action--border action-show video-more" data-group="video-more-group"><?php echo esc_html__( 'More', 'haru-vidi' ); ?><i class="haru-icon haru-dots"></i></div>

