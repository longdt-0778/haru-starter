<?php
/**
 * @package    HaruTheme/Haru Vidi
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/

/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */

// Playlist Submit
if ( !function_exists( 'haru_vidi_field_metaboxes_submit_playlist' ) ) {
    function haru_vidi_field_metaboxes_submit_playlist() {
        // Frontend Submit Form - Playlist
        $playlist_submit = new_cmb2_box( array(
            'id'           => 'haru-playlist-submit-form',
            'object_types' => array( 'haru_playlist' ), // change to other posttype: post, haru_playlist
            'hookup'       => false,
            'save_fields'  => false,
        ) );

        $default_title = '';
        $default_content = '';
        if ( !empty( $_POST ) ) {
            if ( isset( $_POST['haru_playlist_submit_title'] ) ) {
                $default_title = $_POST['haru_playlist_submit_title'];
            }

            if ( array_key_exists('haru_playlist_submit_content', $_POST) ) {
                $default_content = $_POST['haru_playlist_submit_content'];
            }
        } else { 
            $default_title = isset( $_GET['playlist_edit'] ) ? get_the_title( absint( $_GET['playlist_edit'] ) ) : esc_html__( 'New Playlist', 'haru-vidi' );
            $default_content = isset( $_GET['playlist_edit'] )
                ? apply_filters( 'the_content', get_post_field( 'post_content', absint( $_GET['playlist_edit'] ) ) )
                : '';
        }

        $playlist_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'    => esc_html__( 'New Playlist Title', 'haru-vidi' ),
            'id'      => 'haru_playlist_submit_title',
            'type'    => 'text',
            'default' => $default_title,
        ) );

        $playlist_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'       => esc_html__( 'New Playlist Content', 'haru-vidi' ),
            'id'         => 'haru_playlist_submit_content',
            'type'       => 'wysiwyg',
            'options'    => array(
                'textarea_rows' => 12,
                'media_buttons' => false,
            ),
            'default'   => $default_content,
        ) );

        $playlist_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'       => esc_html__( 'Featured Image', 'haru-vidi' ),
            'id'         => 'haru_playlist_thumbnail',
            'type'       => 'text',
            'attributes' => array(
                'type' => 'file', // Let's use a standard file upload field
            ),
        ) );

        $playlist_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'       => esc_html__( 'Categories', 'haru-vidi' ),
            'id'         => 'haru_playlist_submit_categories',
            'type'       => 'taxonomy_multicheck_hierarchical',
            'taxonomy'   => 'playlist_category', // Taxonomy Slug
        ) );

        $playlist_submit->add_field( array(
            'default_cb'   => 'haru_maybe_set_default_from_posted_values',
            'name'    => esc_html__( 'Attached Videos', 'haru-vidi' ),
            'desc'    => esc_html__( 'Drag videos from the left column to the right column to add them to this playlist. You may rearrange the order of the videos in the right column by dragging and dropping.', 'haru-vidi' ),
            'id'      => 'haru_playlist_attached_videos',
            'type'    => 'custom_attached_posts',
            'column'  => true, // Output in the admin post-listing as a custom column. https://github.com/CMB2/CMB2/wiki/Field-Parameters#column
            'options' => array(
                'show_thumbnails' => true, // Show thumbnails on the left
                'filter_boxes'    => true, // Show a text box for filtering the results
                'query_args'      => array(
                    'posts_per_page' => 10,
                    'post_type'      => 'haru_video',
                ), // override the get_posts args
            ),
        ) );

        $playlist_submit->add_field( array(
            'default_cb'   => 'haru_maybe_set_default_from_posted_values',
            'name'    => esc_html__( 'Attached Channels', 'haru-vidi' ),
            'desc'    => esc_html__( 'Drag channels from the left column to the right column to add them to this playlist. You may rearrange the order of the channels in the right column by dragging and dropping.', 'haru-vidi' ),
            'id'      => 'haru_playlist_attached_channels',
            'type'    => 'custom_attached_posts',
            'column'  => true, // Output in the admin post-listing as a custom column. https://github.com/CMB2/CMB2/wiki/Field-Parameters#column
            'options' => array(
                'show_thumbnails' => true, // Show thumbnails on the left
                'filter_boxes'    => true, // Show a text box for filtering the results
                'query_args'      => array(
                    'posts_per_page' => 10,
                    'post_type'      => 'haru_channel',
                ), // override the get_posts args
            ),
        ) );
    }

    add_action( 'cmb2_init', 'haru_vidi_field_metaboxes_submit_playlist' );
}

/**
 * Gets the haru-playlist-submit-form cmb instance
 *
 * @return CMB2 object
 */
function haru_playlist_submit_cmb2_get() {
    // Use ID of metabox in haru_frontend_form_register
    $metabox_id = 'haru-playlist-submit-form';
    // Post/object ID is not applicable since we're using this form for submission
    $object_id  = 'fake-object-id';
    // Get CMB2 metabox object
    return cmb2_get_metabox( $metabox_id, $object_id );
}

/**
 * Handle the haru_playlist_submit_form shortcode
 *
 * @param  array  $atts Array of shortcode attributes
 * @return string       Form html
 */
function haru_do_frontend_form_submission_playlist_shortcode( $atts = array() ) {
    // Get CMB2 metabox object
    if ( isset( $_GET['playlist_edit'] ) && ( $post = get_post( absint( $_GET['playlist_edit'] ) ) ) ) {
        // Edit post
        $metabox_id = 'haru-playlist-submit-form';
        $object_id = absint( $_GET['playlist_edit'] );
        $playlist_submit = cmb2_get_metabox( $metabox_id, $object_id );

        // Get $playlist_submit object_types
        $post_types = $playlist_submit->prop( 'object_types' );
        // Current user
        $user_id = get_current_user_id();
        // Parse attributes
        $atts = shortcode_atts( array(
            'post_author' => $user_id ? $user_id : 1, // Current user, or admin
            'post_status' => 'pending',
            'post_type'   => reset( $post_types ), // Only use first object_type in array
        ), $atts, 'haru_playlist_submit_form' );
        /*
         * Let's add these attributes as hidden fields to our cmb form
         * so that they will be passed through to our form submission
         */
        foreach ( $atts as $key => $value ) {
            $playlist_submit->add_hidden_field( array(
                    'field_args'    => array(
                    'id'            => "atts-playlist[$key]",
                    'type'          => 'hidden',
                    'default'       => $value,
                ),
            ) );
        }

        // Initiate our output variable
        $output = '';
        $submit_allow = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_submit_allow', 'off' );

        if ( $submit_allow == 'on' ) {
            // @TODO: User logged in here or process when submit
            if ( is_user_logged_in() ) {
                // Get any submission errors
                if ( ( $error = $playlist_submit->prop( 'submission_error' ) ) && is_wp_error( $error ) ) {
                    // If there was an error with the submission, add it to our ouput.
                    $output .= '<h6 class="message-submit-error">' . sprintf( esc_html__( 'There was an error in the submission: %s', 'haru-vidi' ), '<strong>'. $error->get_error_message() .'</strong>' ) . '</h6>';
                }

                $output .= '<div class="video-submit-notice">';
                $output .= '<h6 class="video-submit-notice-title">' . esc_html__( 'Playlist Submit information depend on your account Level', 'haru-vidi' ) . '</h6>';

                // Process File upload size
                $max_file_size_image = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_image_upload_max_size', '2' );

                // Processe Membership
                $member_integrate       = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_integrate', 'off' );

                if ( $member_integrate == 'on' ) {
                    $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );

                    // PaidMembershipsPro
                    if ( $member_plugin == 'pmpro' ) {
                        // Process Membership
                        $membership_level = pmpro_getMembershipLevelForUser( $user_id ); // pmpro_getMembershipLevelsForUser
                        $startdate = date_i18n( get_option( 'date_format' ), $membership_level->startdate );
                        if ( $membership_level->enddate != '0' ) {
                            $enddate = date_i18n( get_option( 'date_format' ), $membership_level->enddate );
                        } else {
                            $enddate = '0';
                        }

                        $output .= '<p class="user-subscription">' . esc_html__( 'Your current Subcription is ', 'haru-vidi' ) . '<strong>' . $membership_level->name . '</strong></p>';
                        $output .= '<p class="user-subscription-start">' . esc_html__( 'Your Subcription start at ', 'haru-vidi' ) . '<strong>' . $startdate . '</strong></p>';

                        if ( $enddate == '0' ) {
                            $output .= '<p class="user-subscription-end">' . esc_html__( 'Your Subcription does not have End date.', 'haru-vidi' ) . '</p>';
                        } else {
                            $output .= '<p class="user-subscription-end">' . esc_html__( 'Your Subcription end at ', 'haru-vidi' ) . '<strong>' . $enddate . '</strong></p>';
                        }

                        $member_settings_levels = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_pmpro_levels_group', '' );

                        foreach ( $member_settings_levels as $setting_level ) {
                            if ( $setting_level['haru_member_pmpro_level'] == $membership_level->id ) {
                                $max_file_size_image = $setting_level['haru_member_pmpro_image_max_size'];
                            }
                        }

                    }
                }

                $output .= '<p class="upload-image-filesize">' . esc_html__( 'Image Upload max file size is ', 'haru-vidi' ) . '<strong>' . $max_file_size_image . 'MB' . '</strong></p>';

                // Processe Membership
                if ( $member_integrate == 'on' ) {
                    $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );
                    $pmpro_pages   = pmpro_get_pmpro_pages();

                    // PaidMembershipsPro
                    if ( $member_plugin == 'pmpro' ) {
                        $output .= '<div class="user-subscription-action"><a href="' . haru_get_url_of_page_with_id( $pmpro_pages['levels'] ) . '" class="pmpro-require-btn button-background button-background--primary button-background--medium" target="_blank">' . esc_html__( 'Change Subcription', 'haru-vidi' ) . '</a></div>';
                    }
                }

                $output .= '</div>';

                // Get our form
                $object_id = absint( $_GET['playlist_edit'] );

                $output .= cmb2_get_metabox_form( $playlist_submit, $object_id, array( 'save_button' => esc_html__( 'Save Playlist', 'haru-vidi' ) ) );
            } else {
                $output .= '<div class="message-submit-warning">' . esc_html__( 'Please logged in to submit.', 'haru-vidi' ) . '</h6>';
            }
        } else {
            $output .= '<h6 class="message-submit-warning">' . esc_html__( 'This site doesn\'t allow to submit playlist.', 'haru-vidi' ) . '</h6>';
        }

        return $output;
    } else {
        $playlist_submit = haru_playlist_submit_cmb2_get();
        // Get $playlist_submit object_types
        $post_types = $playlist_submit->prop( 'object_types' );
        // Current user
        $user_id = get_current_user_id();
        // Parse attributes
        $atts = shortcode_atts( array(
            'post_author' => $user_id ? $user_id : 1, // Current user, or admin
            'post_status' => 'pending',
            'post_type'   => reset( $post_types ), // Only use first object_type in array
        ), $atts, 'haru_playlist_submit_form' );
        /*
         * Let's add these attributes as hidden fields to our cmb form
         * so that they will be passed through to our form submission
         */
        foreach ( $atts as $key => $value ) {
            $playlist_submit->add_hidden_field( array(
                    'field_args'    => array(
                    'id'            => "atts-playlist[$key]",
                    'type'          => 'hidden',
                    'default'       => $value,
                ),
            ) );
        }

        // Initiate our output variable
        $output = '';
        $submit_allow = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_submit_allow', 'off' );

        if ( $submit_allow == 'on' ) {
            // @TODO: User logged in here or process when submit
            if ( is_user_logged_in() ) {
                // Get any submission errors
                if ( ( $error = $playlist_submit->prop( 'submission_error' ) ) && is_wp_error( $error ) ) {
                    // If there was an error with the submission, add it to our ouput.
                    $output .= '<h6 class="message-submit-error">' . sprintf( esc_html__( 'There was an error in the submission: %s', 'haru-vidi' ), '<strong>'. $error->get_error_message() .'</strong>' ) . '</h6>';
                }
                // If the post was submitted successfully, notify the user.
                if ( isset( $_GET['post_submitted'] ) && ( $post = get_post( absint( $_GET['post_submitted'] ) ) ) ) {
                    // Get submitter's name
                    $current_user    = wp_get_current_user();
                    $name = $current_user->user_login;
                    $name = $name ? ' '. $name : '';
                    // Add notice of submission to our output
                    $output .= '<h6 class="message-submit-success">' . sprintf( esc_html__( 'Thank you%s, your new post has been submitted and is pending review by a site administrator.', 'haru-vidi' ), esc_html( $name ) ) . '</h6>';
                }

                // @TODO: User logged in here or process when submit
                $output .= '<div class="video-submit-notice">';
                $output .= '<h6 class="video-submit-notice-title">' . esc_html__( 'Playlist Submit information depend on your account Level', 'haru-vidi' ) . '</h6>';

                // Process File upload size
                $max_file_size_image = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_image_upload_max_size', '2' );

                // Processe Membership
                $member_integrate       = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_integrate', 'off' );

                if ( $member_integrate == 'on' ) {
                    $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );

                    // PaidMembershipsPro
                    if ( $member_plugin == 'pmpro' ) {
                        // Process Membership
                        $membership_level = pmpro_getMembershipLevelForUser( $user_id ); // pmpro_getMembershipLevelsForUser
                        $startdate = date_i18n( get_option( 'date_format' ), $membership_level->startdate );
                        if ( $membership_level->enddate != '0' ) {
                            $enddate = date_i18n( get_option( 'date_format' ), $membership_level->enddate );
                        } else {
                            $enddate = '0';
                        }

                        $output .= '<p class="user-subscription">' . esc_html__( 'Your current Subcription is ', 'haru-vidi' ) . '<strong>' . $membership_level->name . '</strong></p>';
                        $output .= '<p class="user-subscription-start">' . esc_html__( 'Your Subcription start at ', 'haru-vidi' ) . '<strong>' . $startdate . '</strong></p>';

                        if ( $enddate == '0' ) {
                            $output .= '<p class="user-subscription-end">' . esc_html__( 'Your Subcription does not have End date.', 'haru-vidi' ) . '</p>';
                        } else {
                            $output .= '<p class="user-subscription-end">' . esc_html__( 'Your Subcription end at ', 'haru-vidi' ) . '<strong>' . $enddate . '</strong></p>';
                        }

                        $member_settings_levels = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_pmpro_levels_group', '' );

                        foreach ( $member_settings_levels as $setting_level ) {
                            if ( $setting_level['haru_member_pmpro_level'] == $membership_level->id ) {
                                $max_file_size_image = $setting_level['haru_member_pmpro_image_max_size'];
                            }
                        }

                    }
                }

                $output .= '<p class="upload-image-filesize">' . esc_html__( 'Image Upload max file size is ', 'haru-vidi' ) . '<strong>' . $max_file_size_image . 'MB' . '</strong></p>';

                // Processe Membership
                if ( $member_integrate == 'on' ) {
                    $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );
                    $pmpro_pages   = pmpro_get_pmpro_pages();

                    // PaidMembershipsPro
                    if ( $member_plugin == 'pmpro' ) {
                        $output .= '<div class="user-subscription-action"><a href="' . haru_get_url_of_page_with_id( $pmpro_pages['levels'] ) . '" class="pmpro-require-btn button-background button-background--primary button-background--medium" target="_blank">' . esc_html__( 'Change Subcription', 'haru-vidi' ) . '</a></div>';
                    }
                }

                $output .= '</div>';

                $output .= cmb2_get_metabox_form( $playlist_submit, 'fake-object-id', array( 'save_button' => esc_html__( 'Submit Playlist', 'haru-vidi' ) ) );
            } else {
                $output .= '<h6 class="message-submit-warning">' . esc_html__( 'Please logged in to submit.', 'haru-vidi' ) . '</h6>';
            }
        } else {
            $output .= '<h6 class="message-submit-warning">' . esc_html__( 'This site doesn\'t allow to submit playlist.', 'haru-vidi' ) . '</h6>';
        }

        return $output;
    }
}
add_shortcode( 'haru_playlist_submit_form', 'haru_do_frontend_form_submission_playlist_shortcode' );

/**
 * Handles form submission on save. Redirects if save is successful, otherwise sets an error message as a cmb property
 *
 * @return void
 */
function haru_handle_frontend_new_playlist_form_submission() {
    // Get CMB2 metabox object
    if ( isset( $_GET['playlist_edit'] ) && ( $post = get_post( absint( $_GET['playlist_edit'] ) ) ) ) {
        // If no form submission, bail
        if ( empty( $_POST ) || ! isset( $_POST['submit-cmb'], $_POST['object_id'] ) ) {
            return false;
        }

        // Edit post
        $metabox_id = 'haru-playlist-submit-form';
        $object_id = absint( $_GET['playlist_edit'] );
        $playlist_submit = cmb2_get_metabox( $metabox_id, $object_id );

        // Update post
        $post_data = array();
        // Get our shortcode attributes and set them as our initial post_data args
        if ( isset( $_POST['atts-playlist'] ) ) {
            foreach ( (array) $_POST['atts-playlist'] as $key => $value ) {
                $post_data[ $key ] = sanitize_text_field( $value );
            }
            unset( $_POST['atts-playlist'] );
        }

        // @TODO: Process membership role here
        if ( !is_user_logged_in() ) {
            return $playlist_submit->prop( 'submission_error', new WP_Error( 'user_logged_out', __( 'You must logged in to submit.' ) ) );
        }
        // Check security nonce
        if ( ! isset( $_POST[ $playlist_submit->nonce() ] ) || ! wp_verify_nonce( $_POST[ $playlist_submit->nonce() ], $playlist_submit->nonce() ) ) {
            return $playlist_submit->prop( 'submission_error', new WP_Error( 'security_fail', __( 'Security check failed.' ) ) );
        }
        // Check title submitted
        if ( empty( $_POST['haru_playlist_submit_title'] ) ) {
            return $playlist_submit->prop( 'submission_error', new WP_Error( 'post_data_missing', __( 'New playlist requires a title.' ) ) );
        }
        // Check content submitted
        if ( empty( $_POST['haru_playlist_submit_content'] ) ) {
            return $playlist_submit->prop( 'submission_error', new WP_Error( 'post_data_missing', __( 'New playlist requires have content.' ) ) );
        }

        // Check file validate
        $validate_thumbnail     = haru_frontend_form_playlist_photo_upload_validate();
        $validate_membership    = haru_frontend_form_membership_subscription_validate();
        if ( is_wp_error( $validate_thumbnail ) || is_wp_error( $validate_membership ) ) {
            return;
        }

        // @TODO: And that the title is not the default title

        /**
         * Fetch sanitized values
         */
        $sanitized_values = $playlist_submit->get_sanitized_values( $_POST );
        // Set our post data arguments
        $post_data['post_title']   = $sanitized_values['haru_playlist_submit_title'];
        unset( $sanitized_values['haru_playlist_submit_title'] );

        if ( array_key_exists('haru_playlist_submit_content', $sanitized_values) ) {
            $post_data['post_content'] = $sanitized_values['haru_playlist_submit_content'];
            unset( $sanitized_values['haru_playlist_submit_content'] );
        }

        // @TODO: can add setting here
        $post_data['post_status'] = 'publish';

        $new_submission_id = absint( $_GET['playlist_edit'] );
        // If we hit a snag, update the user
        if ( is_wp_error( $new_submission_id ) ) {
            return $playlist_submit->prop( 'submission_error', $new_submission_id );
        }

        $post_data['ID'] = $new_submission_id;
        $result_update = wp_update_post( $post_data, true );

        $playlist_submit->save_fields( $new_submission_id, 'post', $sanitized_values );
        /**
         * Other than post_type and post_status, we want
         * our uploaded attachment post to have the same post-data
         */
        unset( $post_data['post_type'] );
        unset( $post_data['post_status'] );

        // Try to upload the featured image
        $img_id = haru_frontend_form_playlist_photo_upload( $new_submission_id, $post_data );
        remove_filter( 'upload_dir', 'haru_vidi_upload_dir_images' );
        // If our photo upload was successful, set the featured image
        if ( $img_id && ! is_wp_error( $img_id ) ) {
            set_post_thumbnail( $new_submission_id, $img_id );
        }
    } else {
        // If no form submission, bail
        if ( empty( $_POST ) || ! isset( $_POST['submit-cmb'], $_POST['object_id'] ) ) {
            return false;
        }

        $playlist_submit = haru_playlist_submit_cmb2_get();
        $post_data = array();
        // Get our shortcode attributes and set them as our initial post_data args
        if ( isset( $_POST['atts-playlist'] ) ) {
            foreach ( (array) $_POST['atts-playlist'] as $key => $value ) {
                $post_data[ $key ] = sanitize_text_field( $value );
            }
            unset( $_POST['atts-playlist'] );
        }

        // @TODO: Process membership role here
        if ( !is_user_logged_in() ) {
            return $playlist_submit->prop( 'submission_error', new WP_Error( 'user_logged_out', __( 'You must logged in to submit.' ) ) );
        }
        // Check security nonce
        if ( ! isset( $_POST[ $playlist_submit->nonce() ] ) || ! wp_verify_nonce( $_POST[ $playlist_submit->nonce() ], $playlist_submit->nonce() ) ) {
            return $playlist_submit->prop( 'submission_error', new WP_Error( 'security_fail', __( 'Security check failed.' ) ) );
        }
        // Check title submitted
        if ( empty( $_POST['haru_playlist_submit_title'] ) ) {
            return $playlist_submit->prop( 'submission_error', new WP_Error( 'post_data_missing', __( 'New playlist requires a title.' ) ) );
        }
        // Check content submitted
        if ( empty( $_POST['haru_playlist_submit_content'] ) ) {
            return $playlist_submit->prop( 'submission_error', new WP_Error( 'post_data_missing', __( 'New playlist requires have content.' ) ) );
        }

        // Check file validate
        $validate_thumbnail     = haru_frontend_form_playlist_photo_upload_validate();
        $validate_membership    = haru_frontend_form_membership_subscription_validate();
        if ( is_wp_error( $validate_thumbnail ) || is_wp_error( $validate_membership ) ) {
            return;
        }

        // @TODO: And that the title is not the default title

        /**
         * Fetch sanitized values
         */
        $sanitized_values = $playlist_submit->get_sanitized_values( $_POST );

        // Set our post data arguments
        $post_data['post_title']   = $sanitized_values['haru_playlist_submit_title'];
        unset( $sanitized_values['haru_playlist_submit_title'] );
        $post_data['post_content'] = $sanitized_values['haru_playlist_submit_content'];
        unset( $sanitized_values['haru_playlist_submit_content'] );

        // Create the new post
        $new_submission_id = wp_insert_post( $post_data, true );
        // If we hit a snag, update the user
        if ( is_wp_error( $new_submission_id ) ) {
            return $playlist_submit->prop( 'submission_error', $new_submission_id );
        }

        $playlist_submit->save_fields( $new_submission_id, 'post', $sanitized_values );

        // Use for email
        $post_type = $post_data['post_type'];
        
        /**
         * Other than post_type and post_status, we want
         * our uploaded attachment post to have the same post-data
         */
        unset( $post_data['post_type'] );
        unset( $post_data['post_status'] );
        // Try to upload the featured image
        $img_id = haru_frontend_form_playlist_photo_upload( $new_submission_id, $post_data );
        remove_filter( 'upload_dir', 'haru_vidi_upload_dir_images' );
        // If our photo upload was successful, set the featured image
        if ( $img_id && ! is_wp_error( $img_id ) ) {
            set_post_thumbnail( $new_submission_id, $img_id );
        }

        /*
         * Process Email after user submit.
         */
        $site_name       = get_option('blogname');
        $current_user    = wp_get_current_user();
        $replace_array   = array(
                            'first_name'        => $current_user->user_firstname, 
                            'last_name'         => $current_user->user_lastname, 
                            'user_name'         => $current_user->user_login, 
                            'user_email'        => $current_user->user_email, 
                            'post_title'        => $post_data['post_title'],
                            'post_type'         => get_post_type_object( $post_type )->label,
                            'site_name'         => $site_name,
                        );

        $haru_email_submit_admin = haru_vidi_get_setting( 'vidi-email-settings', 'haru_email_submit_admin', 'off' );

        if ( $haru_email_submit_admin  == 'on' ) {
            $admin_headers = array('MIME-Version: 1.0\r\n', 'Content-Type: text/html; charset=ISO-8859-1\r\n');
            $admin_email   = haru_vidi_get_setting( 'vidi-email-settings', 'haru_email_admin_email');

            if ( !isset( $admin_email ) ) {
                $admin_email = get_option('admin_email');
            }
            $playlist_submit_admin_subject  = haru_vidi_get_setting( 'vidi-email-settings', 'haru_email_admin_subject' );
            $playlist_submit_admin_header   = haru_vidi_get_setting( 'vidi-email-settings', 'haru_email_admin_header' );
            $playlist_submit_admin_messsage = haru_vidi_get_setting( 'vidi-email-settings', 'haru_email_admin_content' );

            $admin_subject           = haru_vidi_process_email_template($replace_array, $playlist_submit_admin_subject);
            $admin_headers[]         = haru_vidi_process_email_template($replace_array, $playlist_submit_admin_header);
            $admin_message           = haru_vidi_process_email_template($replace_array, $playlist_submit_admin_messsage);

            $admin_result = wp_mail($admin_email, $admin_subject, $admin_message, $admin_headers);

            if ( $admin_result ) {
                return $playlist_submit->prop( 'submission_error', new WP_Error( 'email_sucessful', __( 'Your playlist has been submitted!' ) ) );
            } else {
                return $playlist_submit->prop( 'submission_error', new WP_Error( 'email_fail', __( 'Cannot send email. Please try again later!' ) ) );
            }
        }

        /*
         * Redirect back to the form page with a query variable with the new post ID.
         * This will help double-submissions with browser refreshes
         */
        wp_redirect( esc_url_raw( add_query_arg( 'post_submitted', $new_submission_id ) ) );

        exit;
    }
}
add_action( 'cmb2_after_init', 'haru_handle_frontend_new_playlist_form_submission' );

/**
 * Handles uploading a file to a WordPress post
 *
 * @param  int   $post_id              Post ID to upload the photo to
 * @param  array $attachment_post_data Attachement post-data array
 */

function haru_frontend_form_playlist_photo_upload_validate() {
    // Make sure the right files were submitted
    if (
        empty( $_FILES )
        || ! isset( $_FILES['haru_playlist_thumbnail'] )
        || isset( $_FILES['haru_playlist_thumbnail']['error'] ) && 0 !== $_FILES['haru_playlist_thumbnail']['error']
    ) {
        return;
    }

    // Filter out empty array values
    $files = array_filter( $_FILES['haru_playlist_thumbnail'] );

    // Make sure files were submitted at all
    if ( empty( $files ) ) {
        return;
    }

    // Check file size
    $playlist_submit = haru_playlist_submit_cmb2_get();
    $max_file_size_image = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_image_upload_max_size', '2' ); // MB convert to B

    // Processe Membership
    $member_integrate       = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_integrate', 'off' );

    if ( $member_integrate == 'on' ) {
        $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );

        // PaidMembershipsPro
        if ( $member_plugin == 'pmpro' ) {
            // Process Membership
            $membership_level       = pmpro_getMembershipLevelForUser( $user_id ); // @TODO: pmpro_getMembershipLevelsForUser
            $member_settings_levels = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_pmpro_levels_group', '' );

            foreach ( $member_settings_levels as $setting_level ) {
                if ( $setting_level['haru_member_pmpro_level'] == $membership_level->id ) {
                    $max_file_size_image = $setting_level['haru_member_pmpro_image_max_size'];
                }
            }

        }
    }

    if ( $files['size'] > ( $max_file_size_image * 1024 * 1024 ) ) {
        return $video_submit->prop( 'submission_error', new WP_Error( 'image_file_size_fail', __( 'Your upload Image file is too large!' ) ) );
    }
}

function haru_frontend_form_playlist_photo_upload( $post_id, $attachment_post_data = array() ) {
    // Make sure to include the WordPress media uploader API if it's not (front-end)
    if ( ! function_exists( 'media_handle_upload' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );
    }

    add_filter( 'upload_dir', 'haru_vidi_upload_dir_images' );
    // Upload the file and send back the attachment post ID
    return media_handle_upload( 'haru_playlist_thumbnail', $post_id, $attachment_post_data );
}

