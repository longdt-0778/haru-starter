<?php
/**
 * @package    HaruTheme/Haru Vidi
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/

/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */

// Video Submit
if ( !function_exists( 'haru_vidi_field_metaboxes_submit_video' ) ) {
    function haru_vidi_field_metaboxes_submit_video() {
        // Frontend Submit Form - Video
        $video_submit = new_cmb2_box( array(
            'id'           => 'haru-video-submit-form',
            'object_types' => array( 'haru_video' ), // change to other posttype: post, haru_video
            'hookup'       => false,
            'save_fields'  => false,
        ) );

        $default_title = '';
        $default_content = '';
        if ( !empty( $_POST ) ) {
            if ( isset( $_POST['haru_video_submit_title'] ) ) {
                $default_title = $_POST['haru_video_submit_title'];
            }

            if ( array_key_exists('haru_video_submit_content', $_POST) ) {
                $default_content = $_POST['haru_video_submit_content'];
            }
        } else { 
            $default_title = isset( $_GET['video_edit'] ) ? get_the_title( absint( $_GET['video_edit'] ) ) : esc_html__( 'New Video', 'haru-vidi' );
            $default_content = isset( $_GET['video_edit'] )
                ? apply_filters( 'the_content', get_post_field( 'post_content', absint( $_GET['video_edit'] ) ) )
                : '';
        }

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'    => esc_html__( 'New Video Title', 'haru-vidi' ),
            'id'      => 'haru_video_submit_title',
            'type'    => 'text',
            'default' => $default_title,
            'attributes'    => array(
                'required'               => true, // Will be required only if visible.
            )
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'       => esc_html__( 'New Video Content', 'haru-vidi' ),
            'id'         => 'haru_video_submit_content',
            'type'       => 'wysiwyg',
            'options'    => array(
                'textarea_rows' => 12,
                'media_buttons' => false,
            ),
            'default'   => $default_content,
            'attributes'    => array(
                'required'               => true, // Will be required only if visible.
            )
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'              => esc_html__( 'Source Server', 'haru-vidi' ),
            'id'                => 'haru_video' . '_server',
            'type'              => 'pw_select',
            'show_option_none'  => false,
            'options'           => array(
                'youtube'       => esc_html__( 'Youtube','haru-vidi' ),
                'vimeo'         => esc_html__( 'Vimeo','haru-vidi' ),
                'twitch'        => esc_html__( 'Twitch','haru-vidi' ),
                'dailymotion'   => esc_html__( 'Dailymotion','haru-vidi' ),
                'facebook'      => esc_html__( 'Facebook','haru-vidi' ),
                'google'        => esc_html__( 'Drive Google','haru-vidi' ),
                'selfhost'      => esc_html__( 'Self Host','haru-vidi' ),
                'embed'         => esc_html__( 'Embed','haru-vidi' ),
            ),
            'default'          => 'youtube',
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'id'      => 'haru_video' . '_id',
            'name'    => esc_html__( 'Video ID', 'haru-vidi' ),
            'desc'    => esc_html__( 'Insert Video ID from Youtube, Vimeo,... server.', 'haru-vidi' ),
            'type'    => 'text',
            'attributes'    => array(
                'required'               => true, // Will be required only if visible.
                'data-conditional-id'    => 'haru_video_server',
                'data-conditional-value' => wp_json_encode( array('youtube', 'vimeo', 'dailymotion', 'twitch') ),
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'id'      => 'haru_video' . '_facebook_url',
            'name'    => esc_html__( 'Video Facebook Url', 'haru-vidi' ),
            'desc'    => esc_html__( 'Insert Video Url from Facebook.', 'haru-vidi' ),
            'type'    => 'text_url',
            'attributes'    => array(
                'required'               => true, // Will be required only if visible.
                'data-conditional-id'    => 'haru_video_server',
                'data-conditional-value' => wp_json_encode( array('facebook') ),
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'id'      => 'haru_video' . '_google_url',
            'name'    => esc_html__( 'Video Google Url', 'haru-vidi' ),
            'desc'    => esc_html__( 'Insert Video Url from Google Drive.', 'haru-vidi' ),
            'type'    => 'text_url',
            'attributes'    => array(
                'required'               => true, // Will be required only if visible.
                'data-conditional-id'    => 'haru_video_server',
                'data-conditional-value' => wp_json_encode( array('google') ),
            ),
        ) );

        $submit_allow_upload = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_submit_allow_upload_video', 'off' );
        if ( $submit_allow_upload == 'on' ) {
            $video_submit->add_field( array(
                'default_cb' => 'haru_maybe_set_default_from_posted_values',
                'name'              => esc_html__( 'Video Source', 'haru-vidi' ),
                'id'                => 'haru_video' . '_url_type',
                'desc'              => esc_html__( 'Use Upload video or Insert Video Url from other server (mp4 and webm).', 'haru-vidi' ),
                'type'              => 'pw_select',
                'show_option_none'  => false,
                'options'           => array(
                    'insert'       => esc_html__( 'Insert URL', 'haru-vidi' ),
                    'upload'       => esc_html__( 'Upload File', 'haru-vidi' ),
                ),
                'attributes'        => array(
                    'required'               => true, // Will be required only if visible.
                    'data-conditional-id'    => 'haru_video_server',
                    'data-conditional-value' => wp_json_encode( array('selfhost') ),
                ),
                'default'          => '',
            ) );
        } else {
            $video_submit->add_field( array(
                'default_cb' => 'haru_maybe_set_default_from_posted_values',
                'name'              => esc_html__( 'Video Source', 'haru-vidi' ),
                'id'                => 'haru_video' . '_url_type',
                'desc'              => esc_html__( 'Insert Video Url from other server (mp4 and webm).', 'haru-vidi' ),
                'type'              => 'pw_select',
                'show_option_none'  => false,
                'options'           => array(
                    'insert'       => esc_html__( 'Insert URL', 'haru-vidi' ),
                ),
                'attributes'        => array(
                    'required'               => true, // Will be required only if visible.
                    'data-conditional-id'    => 'haru_video_server',
                    'data-conditional-value' => wp_json_encode( array('selfhost') ),
                ),
                'default'          => '',
            ) );
        }

        $video_submit->add_field( array(
            'default_cb'    => 'haru_maybe_set_default_from_posted_values',
            'id'            => 'haru_video' . '_url',
            'name'          => esc_html__( 'Video Url', 'haru-vidi' ),
            'desc'          => esc_html__( 'Insert Video Url from other server (mp4 and webm).', 'haru-vidi' ),
            'type'          => 'text_list',
            'options'       => array(
                'mp4'       => 'MP4',
                'webm'      => 'WebM',
            ),
            'attributes'    => array(
                'required'               => true, // Will be required only if visible.
                'data-conditional-id'    => 'haru_video_url_type',
                'data-conditional-value' => wp_json_encode( array('insert') ),
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb'    => 'haru_maybe_set_default_from_posted_values',
            'id'      => 'haru_video' . '_file_mp4',
            'name'    => esc_html__( 'Video MP4 File', 'haru-vidi' ),
            'desc'    => esc_html__( 'Upload your video file (MP4).', 'haru-vidi' ),
            'type'       => 'text',
            'attributes'    => array(
                'type'                  => 'file', // Let's use a standard file upload field
                'accept'                => 'video/mp4',
                'required'               => false, // Will be required only if visible.
                'data-conditional-id'    => 'haru_video_url_type',
                'data-conditional-value' => wp_json_encode( array('upload') ),
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb'    => 'haru_maybe_set_default_from_posted_values',
            'id'      => 'haru_video' . '_file_webm',
            'name'    => esc_html__( 'Video WebM File', 'haru-vidi' ),
            'desc'    => esc_html__( 'Upload your video file (WebM).', 'haru-vidi' ),
            'type'       => 'text',
            'attributes'    => array(
                'type'                  => 'file', // Let's use a standard file upload field
                'accept'                => 'video/webm',
                'required'               => false, // Will be required only if visible.
                'data-conditional-id'    => 'haru_video_url_type',
                'data-conditional-value' => wp_json_encode( array('upload') ),
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb'  => 'haru_maybe_set_default_from_posted_values',
            'id'          => 'haru_video'.  '_embed',
            'name'        => esc_html__( 'Embeded or Iframe', 'haru-vidi' ),
            'desc'        => esc_html__( 'Insert Embeded or Iframe.', 'haru-vidi' ),
            'type'        => 'textarea_code',
            'attributes'    => array(
                'required'               => true, // Will be required only if visible.
                'data-conditional-id'    => 'haru_video_server',
                'data-conditional-value' => wp_json_encode( array('embed') ),
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb'    => 'haru_maybe_set_default_from_posted_values',
            'id'            => 'haru_video' .  '_other',
            'name'          => esc_html__( 'Embeded or Iframe, Object tag', 'haru-vidi' ),
            'desc'          => esc_html__( 'Insert Embeded or Iframe, Object tag.', 'haru-vidi' ),
            'type'          => 'textarea',
            'attributes'    => array(
                'required'               => true, // Will be required only if visible.
                'data-conditional-id'    => 'haru_video_server',
                'data-conditional-value' => wp_json_encode( array('other') ),
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb'    => 'haru_maybe_set_default_from_posted_values',
            'id'            => 'haru_video' . '_duration',
            'name'          => esc_html__( 'Video Duration', 'haru-vidi'),
            'type'          => 'text',
            'desc'          => esc_html__( 'You can set Video duration. Example: 3:15', 'haru-vidi' ),
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'       => esc_html__( 'Featured Image', 'haru-vidi' ),
            'id'         => 'haru_video_thumbnail',
            'type'       => 'text',
            'attributes' => array(
                'required'  => true, // Will be required only if visible.
                'type'      => 'file', // Let's use a standard file upload field
                'accept'    => 'image/png, image/jpeg'
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'       => esc_html__( 'Categories', 'haru-vidi' ),
            'id'         => 'haru_video_submit_categories',
            'type'       => 'taxonomy_multicheck_hierarchical',
            'taxonomy'   => 'video_category', // Taxonomy Slug
        ) );

        $video_submit->add_field( array(
            'name' => esc_html__( '', 'haru-vidi' ),
            'desc' => esc_html__( 'Drag from the left column to the right column to add them to this video. You may rearrange the order of the items in the right column by dragging and dropping.', 'haru-vidi' ),
            'type' => 'title',
            'id'   => 'submitted_video_attached_title'
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'    => esc_html__( 'Attached Playlists', 'haru-vidi' ),
            'desc'    => '',
            'id'      => 'haru_video_attached_playlists',
            'type'    => 'custom_attached_posts',
            'column'  => true, // Output in the admin post-listing as a custom column. https://github.com/CMB2/CMB2/wiki/Field-Parameters#column
            'options' => array(
                'show_thumbnails' => true, // Show thumbnails on the left
                'filter_boxes'    => true, // Show a text box for filtering the results
                'query_args'      => array(
                    'posts_per_page' => 10,
                    'post_type'      => 'haru_playlist',
                ), // override the get_posts args
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'    => esc_html__( 'Attached Series', 'haru-vidi' ),
            'desc'    => '',
            'id'      => 'haru_video_attached_seriess',
            'type'    => 'custom_attached_posts',
            'column'  => true, // Output in the admin post-listing as a custom column. https://github.com/CMB2/CMB2/wiki/Field-Parameters#column
            'options' => array(
                'show_thumbnails' => true, // Show thumbnails on the left
                'filter_boxes'    => true, // Show a text box for filtering the results
                'query_args'      => array(
                    'posts_per_page' => 10,
                    'post_type'      => 'haru_series',
                ), // override the get_posts args
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'    => esc_html__( 'Attached Channels', 'haru-vidi' ),
            'desc'    => '',
            'id'      => 'haru_video_attached_channels',
            'type'    => 'custom_attached_posts',
            'column'  => true, // Output in the admin post-listing as a custom column. https://github.com/CMB2/CMB2/wiki/Field-Parameters#column
            'options' => array(
                'show_thumbnails' => true, // Show thumbnails on the left
                'filter_boxes'    => true, // Show a text box for filtering the results
                'query_args'      => array(
                    'posts_per_page' => 10,
                    'post_type'      => 'haru_channel',
                ), // override the get_posts args
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'    => esc_html__( 'Attached Actors', 'haru-vidi' ),
            'desc'    => '',
            'id'      => 'haru_video_attached_actors',
            'type'    => 'custom_attached_posts',
            'column'  => true, // Output in the admin post-listing as a custom column. https://github.com/CMB2/CMB2/wiki/Field-Parameters#column
            'options' => array(
                'show_thumbnails' => true, // Show thumbnails on the left
                'filter_boxes'    => true, // Show a text box for filtering the results
                'query_args'      => array(
                    'posts_per_page' => 10,
                    'post_type'      => 'haru_actor',
                ), // override the get_posts args
            ),
        ) );

        $video_submit->add_field( array(
            'default_cb' => 'haru_maybe_set_default_from_posted_values',
            'name'    => esc_html__( 'Attached Directors', 'haru-vidi' ),
            'desc'    => '',
            'id'      => 'haru_video_attached_directors',
            'type'    => 'custom_attached_posts',
            'column'  => true, // Output in the admin post-listing as a custom column. https://github.com/CMB2/CMB2/wiki/Field-Parameters#column
            'options' => array(
                'show_thumbnails' => true, // Show thumbnails on the left
                'filter_boxes'    => true, // Show a text box for filtering the results
                'query_args'      => array(
                    'posts_per_page' => 10,
                    'post_type'      => 'haru_director',
                ), // override the get_posts args
            ),
        ) );
    }

    add_action( 'cmb2_init', 'haru_vidi_field_metaboxes_submit_video' );
}

/**
 * Sets the haru-video-submit-form field values if form has already been submitted.
 * Use for submit all posttype
 *
 * @return string
 */
function haru_maybe_set_default_from_posted_values( $args, $field ) {
    if ( ! empty( $_POST[ $field->id() ] ) ) {
        return $_POST[ $field->id() ];
    }

    return '';
}

/**
 * Gets the haru-video-submit-form cmb instance
 *
 * @return CMB2 object
 */
function haru_video_submit_cmb2_get() {
    // Use ID of metabox in haru_frontend_form_register
    $metabox_id = 'haru-video-submit-form';
    // Post/object ID is not applicable since we're using this form for submission
    $object_id  = 'fake-object-id';
    // Get CMB2 metabox object
    return cmb2_get_metabox( $metabox_id, $object_id );
}

/**
 * Handle the haru_video_submit_form shortcode
 *
 * @param  array  $atts Array of shortcode attributes
 * @return string       Form html
 */
function haru_do_frontend_form_submission_video_shortcode( $atts = array() ) {
    // Get CMB2 metabox object
    if ( isset( $_GET['video_edit'] ) && ( $post = get_post( absint( $_GET['video_edit'] ) ) ) ) {
        // Edit post
        $metabox_id = 'haru-video-submit-form';
        $object_id = absint( $_GET['video_edit'] );
        $video_submit = cmb2_get_metabox( $metabox_id, $object_id );

        // Get $video_submit object_types
        $post_types = $video_submit->prop( 'object_types' );
        // Current user
        $user_id = get_current_user_id();
        // Parse attributes
        $atts = shortcode_atts( array(
            'post_author' => $user_id ? $user_id : 1, // Current user, or admin
            'post_status' => 'pending',
            'post_type'   => reset( $post_types ), // Only use first object_type in array
        ), $atts, 'haru_video_submit_form' );
        /*
         * Let's add these attributes as hidden fields to our cmb form
         * so that they will be passed through to our form submission
         */
        foreach ( $atts as $key => $value ) {
            $video_submit->add_hidden_field( array(
                    'field_args'    => array(
                    'id'            => "atts-video[$key]",
                    'type'          => 'hidden',
                    'default'       => $value,
                ),
            ) );
        }

        // Initiate our output variable
        $output = '';
        $submit_allow = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_submit_allow', 'off' );

        if ( $submit_allow == 'on' ) {
            // @TODO: User logged in here or process when submit
            if ( is_user_logged_in() ) {
                // Get any submission errors
                if ( ( $error = $video_submit->prop( 'submission_error' ) ) && is_wp_error( $error ) ) {
                    // If there was an error with the submission, add it to our ouput.
                    $output .= '<h6 class="message-submit-error">' . sprintf( esc_html__( 'There was an error in the submission: %s', 'haru-vidi' ), '<strong>'. $error->get_error_message() .'</strong>' ) . '</h6>';
                }

                $output .= '<div class="video-submit-notice">';
                $output .= '<h6 class="video-submit-notice-title">' . esc_html__( 'Video Submit information depend on your account Level', 'haru-vidi' ) . '</h6>';

                // Process File upload size
                $max_file_size_video = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_video_upload_max_size', '10' );
                $max_file_size_image = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_image_upload_max_size', '2' );

                // Processe Membership
                $member_integrate       = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_integrate', 'off' );

                if ( $member_integrate == 'on' ) {
                    $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );

                    // PaidMembershipsPro
                    if ( $member_plugin == 'pmpro' ) {
                        // Process Membership
                        $membership_level = pmpro_getMembershipLevelForUser( $user_id ); // pmpro_getMembershipLevelsForUser
                        $startdate = date_i18n( get_option( 'date_format' ), $membership_level->startdate );
                        if ( $membership_level->enddate != '0' ) {
                            $enddate = date_i18n( get_option( 'date_format' ), $membership_level->enddate );
                        } else {
                            $enddate = '0';
                        }

                        $output .= '<p class="user-subscription">' . esc_html__( 'Your current Subcription is ', 'haru-vidi' ) . '<strong>' . $membership_level->name . '</strong></p>';
                        $output .= '<p class="user-subscription-start">' . esc_html__( 'Your Subcription start at ', 'haru-vidi' ) . '<strong>' . $startdate . '</strong></p>';

                        if ( $enddate == '0' ) {
                            $output .= '<p class="user-subscription-end">' . esc_html__( 'Your Subcription does not have End date.', 'haru-vidi' ) . '</p>';
                        } else {
                            $output .= '<p class="user-subscription-end">' . esc_html__( 'Your Subcription end at ', 'haru-vidi' ) . '<strong>' . $enddate . '</strong></p>';
                        }

                        $member_settings_levels = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_pmpro_levels_group', '' );

                        foreach ( $member_settings_levels as $setting_level ) {
                            if ( $setting_level['haru_member_pmpro_level'] == $membership_level->id ) {
                                $max_file_size_video = $setting_level['haru_member_pmpro_video_max_size'];
                                $max_file_size_image = $setting_level['haru_member_pmpro_image_max_size'];
                            }
                        }

                    }
                }

                $submit_allow_upload = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_submit_allow_upload_video', 'off' );
                if ( $submit_allow_upload == 'on' ) {
                    $output .= '<p class="upload-video-filesize">' . esc_html__( 'Video Upload max file size is ', 'haru-vidi' ) . '<strong>' . $max_file_size_video . 'MB' . '</strong></p>';
                    $output .= '<p class="upload-image-filesize">' . esc_html__( 'Image Upload max file size is ', 'haru-vidi' ) . '<strong>' . $max_file_size_image . 'MB' . '</strong></p>';
                }

                // Processe Membership
                if ( $member_integrate == 'on' ) {
                    $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );
                    $pmpro_pages   = pmpro_get_pmpro_pages();

                    // PaidMembershipsPro
                    if ( $member_plugin == 'pmpro' ) {
                        $output .= '<div class="user-subscription-action"><a href="' . haru_get_url_of_page_with_id( $pmpro_pages['levels'] ) . '" class="pmpro-require-btn button-background button-background--primary button-background--medium" target="_blank">' . esc_html__( 'Change Subcription', 'haru-vidi' ) . '</a></div>';
                    }
                }

                $output .= '</div>';

                // Get our form
                $object_id = absint( $_GET['video_edit'] );

                $output .= cmb2_get_metabox_form( $video_submit, $object_id, array( 'save_button' => esc_html__( 'Save Video', 'haru-vidi' ) ) );
            } else {
                $output .= '<div class="message-submit-warning">' . esc_html__( 'Please logged in to submit.', 'haru-vidi' ) . '</h6>';
            }
        } else {
            $output .= '<h6 class="message-submit-warning">' . esc_html__( 'This site doesn\'t allow to submit video.', 'haru-vidi' ) . '</h6>';
        }

        return $output;
    } else {
        $video_submit = haru_video_submit_cmb2_get();
        // Get $video_submit object_types
        $post_types = $video_submit->prop( 'object_types' );
        // Current user
        $user_id = get_current_user_id();
        // Parse attributes
        $atts = shortcode_atts( array(
            'post_author' => $user_id ? $user_id : 1, // Current user, or admin
            'post_status' => 'pending',
            'post_type'   => reset( $post_types ), // Only use first object_type in array
        ), $atts, 'haru_video_submit_form' );
        /*
         * Let's add these attributes as hidden fields to our cmb form
         * so that they will be passed through to our form submission
         */
        foreach ( $atts as $key => $value ) {
            $video_submit->add_hidden_field( array(
                    'field_args'    => array(
                    'id'            => "atts-video[$key]",
                    'type'          => 'hidden',
                    'default'       => $value,
                ),
            ) );
        }

        // Initiate our output variable
        $output = '';
        $submit_allow = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_submit_allow', 'off' );

        if ( $submit_allow == 'on' ) {
            if ( is_user_logged_in() ) {
                // Get any submission errors
                if ( ( $error = $video_submit->prop( 'submission_error' ) ) && is_wp_error( $error ) ) {
                    // If there was an error with the submission, add it to our ouput.
                    $output .= '<h6 class="message-submit-error">' . sprintf( esc_html__( 'There was an error in the submission: %s', 'haru-vidi' ), '<strong>'. $error->get_error_message() .'</strong>' ) . '</h6>';
                }

                // If the post was submitted successfully, notify the user.
                if ( isset( $_GET['post_submitted'] ) && ( $post = get_post( absint( $_GET['post_submitted'] ) ) ) ) {
                    // Get submitter's name
                    $current_user    = wp_get_current_user();
                    $name = $current_user->user_login;
                    $name = $name ? ' '. $name : '';
                    // Add notice of submission to our output
                    $output .= '<h6 class="message-submit-success">' . sprintf( esc_html__( 'Thank you%s, your new post has been submitted and is pending review by a site administrator.', 'haru-vidi' ), esc_html( $name ) ) . '</h6>';
                }

                // @TODO: User logged in here or process when submit
                $output .= '<div class="video-submit-notice">';
                $output .= '<h6 class="video-submit-notice-title">' . esc_html__( 'Video Submit information depend on your account Level', 'haru-vidi' ) . '</h6>';

                // Process File upload size
                $max_file_size_video = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_video_upload_max_size', '10' );
                $max_file_size_image = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_image_upload_max_size', '2' );
                // Processe Membership
                $member_integrate       = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_integrate', 'off' );

                if ( $member_integrate == 'on' ) {
                    $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );

                    // PaidMembershipsPro
                    if ( $member_plugin == 'pmpro' ) {
                        // Process Membership
                        $membership_level = pmpro_getMembershipLevelForUser( $user_id ); // pmpro_getMembershipLevelsForUser
                        $startdate = date_i18n( get_option( 'date_format' ), $membership_level->startdate );
                        if ( $membership_level->enddate != '0' ) {
                            $enddate = date_i18n( get_option( 'date_format' ), $membership_level->enddate );
                        } else {
                            $enddate = '0';
                        }

                        $output .= '<p class="user-subscription">' . esc_html__( 'Your current Subcription is ', 'haru-vidi' ) . '<strong>' . $membership_level->name . '</strong></p>';
                        $output .= '<p class="user-subscription-start">' . esc_html__( 'Your Subcription start at ', 'haru-vidi' ) . '<strong>' . $startdate . '</strong></p>';

                        if ( (int)$membership_level->enddate < time() ) {
                            $output .= '<p class="user-subscription-end">' . esc_html__( 'Your Subcription has expired!', 'haru-vidi' ) . '</p>';
                        } elseif ( $enddate == '0' ) {
                            $output .= '<p class="user-subscription-end">' . esc_html__( 'Your Subcription does not have End date.', 'haru-vidi' ) . '</p>';
                        } else {
                            $output .= '<p class="user-subscription-end">' . esc_html__( 'Your Subcription end at ', 'haru-vidi' ) . '<strong>' . $enddate . '</strong></p>';
                        }

                        $member_settings_levels = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_pmpro_levels_group', '' );

                        foreach ( $member_settings_levels as $setting_level ) {
                            if ( $setting_level['haru_member_pmpro_level'] == $membership_level->id ) {
                                $max_file_size_video = $setting_level['haru_member_pmpro_video_max_size'];
                                $max_file_size_image = $setting_level['haru_member_pmpro_image_max_size'];
                            }
                        }

                    }
                }
                    
                $submit_allow_upload = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_submit_allow_upload_video', 'off' );
                if ( $submit_allow_upload == 'on' ) {
                    $output .= '<p class="upload-video-filesize">' . esc_html__( 'Video Upload max file size is ', 'haru-vidi' ) . '<strong>' . $max_file_size_video . 'MB' . '</strong></p>';
                    $output .= '<p class="upload-image-filesize">' . esc_html__( 'Image Upload max file size is ', 'haru-vidi' ) . '<strong>' . $max_file_size_image . 'MB' . '</strong></p>';
                }

                // Processe Membership
                if ( $member_integrate == 'on' ) {
                    $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );
                    $pmpro_pages   = pmpro_get_pmpro_pages();

                    // PaidMembershipsPro
                    if ( $member_plugin == 'pmpro' ) {
                        $output .= '<div class="user-subscription-action"><a href="' . haru_get_url_of_page_with_id( $pmpro_pages['levels'] ) . '" class="pmpro-require-btn button-background button-background--primary button-background--medium" target="_blank">' . esc_html__( 'Change Subcription', 'haru-vidi' ) . '</a></div>';
                    }
                }

                $output .= '</div>';

                $output .= cmb2_get_metabox_form( $video_submit, 'fake-object-id', array( 'save_button' => esc_html__( 'Submit Video', 'haru-vidi' ) ) );
            } else {
                $output .= '<h6 class="message-submit-warning">' . esc_html__( 'Please logged in to submit.', 'haru-vidi' ) . '</h6>';
            }
        } else {
            $output .= '<h6 class="message-submit-warning">' . esc_html__( 'This site doesn\'t allow to submit video.', 'haru-vidi' ) . '</h6>';
        }

        return $output;
    }
}
add_shortcode( 'haru_video_submit_form', 'haru_do_frontend_form_submission_video_shortcode' );

/**
 * Handles form submission on save. Redirects if save is successful, otherwise sets an error message as a cmb property
 *
 * @return void
 */
function haru_handle_frontend_new_video_form_submission() {
    // Get CMB2 metabox object
    if ( isset( $_GET['video_edit'] ) && ( $post = get_post( absint( $_GET['video_edit'] ) ) ) ) {
        // If no form submission, bail
        if ( empty( $_POST ) || ! isset( $_POST['submit-cmb'], $_POST['object_id'] ) ) {
            return false;
        }

        // Edit post
        $metabox_id = 'haru-video-submit-form';
        $object_id = absint( $_GET['video_edit'] );
        $video_submit = cmb2_get_metabox( $metabox_id, $object_id );

        // Update post
        $post_data = array();
        // Get our shortcode attributes and set them as our initial post_data args
        if ( isset( $_POST['atts-video'] ) ) {
            foreach ( (array) $_POST['atts-video'] as $key => $value ) {
                $post_data[ $key ] = sanitize_text_field( $value );
            }
            unset( $_POST['atts-video'] );
        }

        // @TODO: Process membership role here
        if ( !is_user_logged_in() ) {
            return $video_submit->prop( 'submission_error', new WP_Error( 'user_logged_out', __( 'You must logged in to submit.' ) ) );
        }
        // Check security nonce
        if ( ! isset( $_POST[ $video_submit->nonce() ] ) || ! wp_verify_nonce( $_POST[ $video_submit->nonce() ], $video_submit->nonce() ) ) {
            return $video_submit->prop( 'submission_error', new WP_Error( 'security_fail', __( 'Security check failed.' ) ) );
        }
        // Check title submitted
        if ( empty( $_POST['haru_video_submit_title'] ) ) {
            return $video_submit->prop( 'submission_error', new WP_Error( 'post_data_missing', __( 'New video requires a title.' ) ) );
        }
        // Check content submitted
        if ( empty( $_POST['haru_video_submit_content'] ) ) {
            return $video_submit->prop( 'submission_error', new WP_Error( 'post_data_missing', __( 'New video requires have content.' ) ) );
        }

        // Check file validate
        $validate_thumbnail     = haru_frontend_form_video_photo_upload_validate();
        $validate_mp4           = haru_frontend_form_video_mp4_upload_validate();
        $validate_webm          = haru_frontend_form_video_webm_upload_validate();
        $validate_membership    = haru_frontend_form_membership_subscription_validate();
        if ( is_wp_error( $validate_thumbnail ) || is_wp_error( $validate_mp4 ) || is_wp_error( $validate_webm ) || is_wp_error( $validate_membership ) ) {
            return;
        }

        // @TODO: And that the title is not the default title

        /**
         * Fetch sanitized values
         */
        $sanitized_values = $video_submit->get_sanitized_values( $_POST );
        // Set our post data arguments
        $post_data['post_title']   = $sanitized_values['haru_video_submit_title'];
        unset( $sanitized_values['haru_video_submit_title'] );

        if ( array_key_exists('haru_video_submit_content', $sanitized_values) ) {
            $post_data['post_content'] = $sanitized_values['haru_video_submit_content'];
            unset( $sanitized_values['haru_video_submit_content'] );
        }

        // @TODO: can add setting here
        $post_data['post_status'] = 'publish';

        $new_submission_id = absint( $_GET['video_edit'] );
        // If we hit a snag, update the user
        if ( is_wp_error( $new_submission_id ) ) {
            return $video_submit->prop( 'submission_error', $new_submission_id );
        }

        $post_data['ID'] = $new_submission_id;
        $result_update = wp_update_post( $post_data, true );

        $video_submit->save_fields( $new_submission_id, 'post', $sanitized_values );
        /**
         * Other than post_type and post_status, we want
         * our uploaded attachment post to have the same post-data
         */
        unset( $post_data['post_type'] );
        unset( $post_data['post_status'] );

        // Try to upload the featured image
        $img_id = haru_frontend_form_video_photo_upload( $new_submission_id, $post_data );
        // If our photo upload was successful, set the featured image
        if ( $img_id && ! is_wp_error( $img_id ) ) {
            set_post_thumbnail( $new_submission_id, $img_id );
        }
    } else {
        // If no form submission, bail
        if ( empty( $_POST ) || ! isset( $_POST['submit-cmb'], $_POST['object_id'] ) ) {
            return false;
        }

        $video_submit = haru_video_submit_cmb2_get();
        $post_data = array();
        // Get our shortcode attributes and set them as our initial post_data args
        if ( isset( $_POST['atts-video'] ) ) {
            foreach ( (array) $_POST['atts-video'] as $key => $value ) {
                $post_data[ $key ] = sanitize_text_field( $value );
            }
            unset( $_POST['atts-video'] );
        }

        // @TODO: Process membership role here
        if ( !is_user_logged_in() ) {
            return $video_submit->prop( 'submission_error', new WP_Error( 'user_logged_out', __( 'You must logged in to submit.' ) ) );
        }

        // Check security nonce
        if ( ! isset( $_POST[ $video_submit->nonce() ] ) || ! wp_verify_nonce( $_POST[ $video_submit->nonce() ], $video_submit->nonce() ) ) {
            return $video_submit->prop( 'submission_error', new WP_Error( 'security_fail', __( 'Security check failed.' ) ) );
        }

        // Check title submitted
        if ( empty( $_POST['haru_video_submit_title'] ) ) {
            return $video_submit->prop( 'submission_error', new WP_Error( 'post_data_missing', __( 'New video requires a title.' ) ) );
        }

        // Check content submitted
        if ( empty( $_POST['haru_video_submit_content'] ) ) {
            return $video_submit->prop( 'submission_error', new WP_Error( 'post_data_missing', __( 'New video requires have content.' ) ) );
        }

        // Check file validate
        $validate_thumbnail     = haru_frontend_form_video_photo_upload_validate();
        $validate_mp4           = haru_frontend_form_video_mp4_upload_validate();
        $validate_webm          = haru_frontend_form_video_webm_upload_validate();
        $validate_membership    = haru_frontend_form_membership_subscription_validate();
        if ( is_wp_error( $validate_thumbnail ) || is_wp_error( $validate_mp4 ) || is_wp_error( $validate_webm ) || is_wp_error( $validate_membership ) ) {
            return;
        }

        // @TODO: And that the title is not the default title

        /**
         * Fetch sanitized values
         */
        $sanitized_values = $video_submit->get_sanitized_values( $_POST );

        // Set our post data arguments
        $post_data['post_title']   = $sanitized_values['haru_video_submit_title'];
        unset( $sanitized_values['haru_video_submit_title'] );
        $post_data['post_content'] = $sanitized_values['haru_video_submit_content'];
        unset( $sanitized_values['haru_video_submit_content'] );

        // Create the new post
        $new_submission_id = wp_insert_post( $post_data, true );
        // If we hit a snag, update the user
        if ( is_wp_error( $new_submission_id ) ) {
            return $video_submit->prop( 'submission_error', $new_submission_id );
        }

        $video_submit->save_fields( $new_submission_id, 'post', $sanitized_values );

        // Use for email
        $post_type = $post_data['post_type'];

        /**
         * Other than post_type and post_status, we want
         * our uploaded attachment post to have the same post-data
         */
        unset( $post_data['post_type'] );
        unset( $post_data['post_status'] );

        // Try to upload video mp4 file
        $video_mp4_file_id = haru_frontend_form_video_mp4_upload( $new_submission_id, $post_data );
        remove_filter( 'upload_dir', 'haru_vidi_upload_dir_videos' );
        // If our video upload was successful, update meta data
        if ( $video_mp4_file_id && ! is_wp_error( $video_mp4_file_id ) ) {
            $attach_url = wp_get_attachment_url($video_mp4_file_id);
            $update = update_post_meta( $new_submission_id, 'haru_video_file_mp4', $attach_url );
        }

        // Try to upload video webm file
        $video_webm_file_id = haru_frontend_form_video_webm_upload( $new_submission_id, $post_data );
        remove_filter( 'upload_dir', 'haru_vidi_upload_dir_videos' );
        // If our video upload was successful, update meta data
        if ( $video_webm_file_id && ! is_wp_error( $video_webm_file_id ) ) {
            $attach_url = wp_get_attachment_url($video_webm_file_id);
            $update = update_post_meta( $new_submission_id, 'haru_video_file_webm', $attach_url );
        }

        // Try to upload the featured image
        $img_id = haru_frontend_form_video_photo_upload( $new_submission_id, $post_data );
        remove_filter( 'upload_dir', 'haru_vidi_upload_dir_images' );
        // If our photo upload was successful, set the featured image
        if ( $img_id && ! is_wp_error( $img_id ) ) {
            set_post_thumbnail( $new_submission_id, $img_id );
        }

        /*
         * Process Email after user submit.
         */
        $site_name       = get_option('blogname');
        $current_user    = wp_get_current_user();
        $replace_array   = array(
                            'first_name'        => $current_user->user_firstname, 
                            'last_name'         => $current_user->user_lastname, 
                            'user_name'         => $current_user->user_login, 
                            'user_email'        => $current_user->user_email, 
                            'post_title'        => $post_data['post_title'],
                            'post_type'         => get_post_type_object( $post_type )->label,
                            'site_name'         => $site_name,
                        );

        $haru_email_submit_admin = haru_vidi_get_setting( 'vidi-email-settings', 'haru_email_submit_admin', 'off' );

        if ( $haru_email_submit_admin  == 'on' ) {
            $admin_headers = array('MIME-Version: 1.0\r\n', 'Content-Type: text/html; charset=ISO-8859-1\r\n');
            $admin_email   = haru_vidi_get_setting( 'vidi-email-settings', 'haru_email_admin_email');

            if ( !isset( $admin_email ) ) {
                $admin_email = get_option('admin_email');
            }
            $video_submit_admin_subject  = haru_vidi_get_setting( 'vidi-email-settings', 'haru_email_admin_subject' );
            $video_submit_admin_header   = haru_vidi_get_setting( 'vidi-email-settings', 'haru_email_admin_header' );
            $video_submit_admin_messsage = haru_vidi_get_setting( 'vidi-email-settings', 'haru_email_admin_content' );

            $admin_subject           = haru_vidi_process_email_template($replace_array, $video_submit_admin_subject);
            $admin_headers[]         = haru_vidi_process_email_template($replace_array, $video_submit_admin_header);
            $admin_message           = haru_vidi_process_email_template($replace_array, $video_submit_admin_messsage);

            $admin_result = wp_mail($admin_email, $admin_subject, $admin_message, $admin_headers);

            if ( $admin_result ) {
                return $video_submit->prop( 'submission_error', new WP_Error( 'email_sucessful', __( 'Your video has been submitted!' ) ) );
            } else {
                return $video_submit->prop( 'submission_error', new WP_Error( 'email_fail', __( 'Cannot send email. Please try again later!' ) ) );
            }
        }

        /*
         * Redirect back to the form page with a query variable with the new post ID.
         * This will help double-submissions with browser refreshes
         */
        wp_redirect( esc_url_raw( add_query_arg( 'post_submitted', $new_submission_id ) ) );

        exit;
    }
}
add_action( 'cmb2_after_init', 'haru_handle_frontend_new_video_form_submission' );

/**
 * Handles uploading a file to a WordPress post
 *
 * @param  int   $post_id              Post ID to upload the photo to
 * @param  array $attachment_post_data Attachement post-data array
 */
function haru_frontend_form_video_photo_upload_validate() {
    // Make sure the right files were submitted
    if (
        empty( $_FILES )
        || ! isset( $_FILES['haru_video_thumbnail'] )
        || isset( $_FILES['haru_video_thumbnail']['error'] ) && 0 !== $_FILES['haru_video_thumbnail']['error']
    ) {
        return;
    }

    // Filter out empty array values
    $files = array_filter( $_FILES['haru_video_thumbnail'] );

    // Make sure files were submitted at all
    if ( empty( $files ) ) {
        return;
    }

    // Check file size
    $video_submit = haru_video_submit_cmb2_get();
    $max_file_size_image = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_image_upload_max_size', '2' ); // MB convert to B

    // Processe Membership
    $member_integrate       = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_integrate', 'off' );

    if ( $member_integrate == 'on' ) {
        $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );

        // PaidMembershipsPro
        if ( $member_plugin == 'pmpro' ) {
            // Process Membership
            $membership_level       = pmpro_getMembershipLevelForUser( $user_id ); // @TODO: pmpro_getMembershipLevelsForUser
            $member_settings_levels = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_pmpro_levels_group', '' );

            foreach ( $member_settings_levels as $setting_level ) {
                if ( $setting_level['haru_member_pmpro_level'] == $membership_level->id ) {
                    $max_file_size_image = $setting_level['haru_member_pmpro_image_max_size'];
                }
            }

        }
    }

    if ( $files['size'] > ( $max_file_size_image * 1024 * 1024 ) ) {
        return $video_submit->prop( 'submission_error', new WP_Error( 'image_file_size_fail', __( 'Your upload Image file is too large!' ) ) );
    }
}

function haru_frontend_form_video_photo_upload( $post_id, $attachment_post_data = array() ) {
    // Make sure to include the WordPress media uploader API if it's not (front-end)
    if ( ! function_exists( 'media_handle_upload' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );
    }

    add_filter( 'upload_dir', 'haru_vidi_upload_dir_images' );
    // Upload the file and send back the attachment post ID
    return media_handle_upload( 'haru_video_thumbnail', $post_id, $attachment_post_data );
}

function haru_vidi_upload_dir_images( $dir_data ) {
    // $dir_data already you might want to use
    $custom_dir = 'vidi/images';

    return [
        'path'      => $dir_data[ 'basedir' ] . '/' . $custom_dir,
        'url'       => $dir_data[ 'url' ] . '/' . $custom_dir,
        'subdir'    => '/' . $custom_dir,
        'basedir'   => $dir_data[ 'error' ],
        'error'     => $dir_data[ 'error' ],
    ];
}

function haru_frontend_form_video_mp4_upload_validate() {
    if (
        empty( $_FILES )
        || ! isset( $_FILES['haru_video_file_mp4'] )
        || isset( $_FILES['haru_video_file_mp4']['error'] ) && 0 !== $_FILES['haru_video_file_mp4']['error']
    ) {
        return;
    }

    // Filter out empty array values
    $files = array_filter( $_FILES['haru_video_file_mp4'] );

    // Make sure files were submitted at all
    if ( empty( $files ) ) {
        return;
    }

    // Check file size
    $video_submit = haru_video_submit_cmb2_get();
    $max_file_size_video = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_video_upload_max_size', '10' ); // MB convert to B

    // Processe Membership
    $member_integrate       = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_integrate', 'off' );

    if ( $member_integrate == 'on' ) {
        $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );

        // PaidMembershipsPro
        if ( $member_plugin == 'pmpro' ) {
            // Process Membership
            $membership_level       = pmpro_getMembershipLevelForUser( $user_id ); // @TODO: pmpro_getMembershipLevelsForUser
            $member_settings_levels = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_pmpro_levels_group', '' );

            foreach ( $member_settings_levels as $setting_level ) {
                if ( $setting_level['haru_member_pmpro_level'] == $membership_level->id ) {
                    $max_file_size_video = $setting_level['haru_member_pmpro_video_max_size'];
                }
            }

        }
    }

    if ( $files['size'] > ( $max_file_size_video * 1024 * 1024 ) ) {
        return $video_submit->prop( 'submission_error', new WP_Error( 'mp4_file_size_fail', __( 'Your upload MP4 file is too large!' ) ) );
    }
}

function haru_frontend_form_video_webm_upload_validate() {
    if (
        empty( $_FILES )
        || ! isset( $_FILES['haru_video_file_webm'] )
        || isset( $_FILES['haru_video_file_webm']['error'] ) && 0 !== $_FILES['haru_video_file_webm']['error']
    ) {
        return;
    }

    // Filter out empty array values
    $files = array_filter( $_FILES['haru_video_file_webm'] );

    // Make sure files were submitted at all
    if ( empty( $files ) ) {
        return;
    }

    // Check file size
    $video_submit = haru_video_submit_cmb2_get();
    $max_file_size_video = haru_vidi_get_setting( 'vidi-submit-settings', 'haru_video_upload_max_size', '10' ); // MB convert to B

    // Processe Membership
    $member_integrate       = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_integrate', 'off' );

    if ( $member_integrate == 'on' ) {
        $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );

        // PaidMembershipsPro
        if ( $member_plugin == 'pmpro' ) {
            // Process Membership
            $membership_level       = pmpro_getMembershipLevelForUser( $user_id ); // @TODO: pmpro_getMembershipLevelsForUser
            $member_settings_levels = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_pmpro_levels_group', '' );

            foreach ( $member_settings_levels as $setting_level ) {
                if ( $setting_level['haru_member_pmpro_level'] == $membership_level->id ) {
                    $max_file_size_video = $setting_level['haru_member_pmpro_video_max_size'];
                }
            }

        }
    }

    if ( $files['size'] > ( $max_file_size_video * 1024 * 1024 ) ) {
        return $video_submit->prop( 'submission_error', new WP_Error( 'webm_file_size_fail', __( 'Your upload WebM file is too large!' ) ) );
    }
}

function haru_frontend_form_video_mp4_upload( $post_id, $attachment_post_data = array() ) {
    // Make sure to include the WordPress media uploader API if it's not (front-end)
    if ( ! function_exists( 'media_handle_upload' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );
    }

    add_filter( 'upload_dir', 'haru_vidi_upload_dir_videos' );
    // Upload the file and send back the attachment post ID
    return media_handle_upload( 'haru_video_file_mp4', $post_id, $attachment_post_data );
}

function haru_frontend_form_video_webm_upload( $post_id, $attachment_post_data = array() ) {
    // Make sure to include the WordPress media uploader API if it's not (front-end)
    if ( ! function_exists( 'media_handle_upload' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );
    }

    add_filter( 'upload_dir', 'haru_vidi_upload_dir_videos' );
    // Upload the file and send back the attachment post ID
    return media_handle_upload( 'haru_video_file_webm', $post_id, $attachment_post_data );
}

function haru_vidi_upload_dir_videos( $dir_data ) {
    // $dir_data already you might want to use
    $custom_dir = 'vidi/videos';

    return [
        'path'      => $dir_data[ 'basedir' ] . '/' . $custom_dir,
        'url'       => $dir_data[ 'url' ] . '/' . $custom_dir,
        'subdir'    => '/' . $custom_dir,
        'basedir'   => $dir_data[ 'error' ],
        'error'     => $dir_data[ 'error' ],
    ];
}

function haru_frontend_form_membership_subscription_validate() {
    $video_submit = haru_video_submit_cmb2_get();

    if ( $member_integrate == 'on' ) {
        $member_plugin = haru_vidi_get_setting( 'vidi-member-settings', 'haru_member_plugin', 'pmpro' );

        // PaidMembershipsPro
        if ( $member_plugin == 'pmpro' ) {
            // Process Membership
            $membership_level = pmpro_getMembershipLevelForUser( $user_id ); // pmpro_getMembershipLevelsForUser
            $startdate = date_i18n( get_option( 'date_format' ), $membership_level->startdate );
            if ( $membership_level->enddate != '0' ) {
                $enddate = date_i18n( get_option( 'date_format' ), $membership_level->enddate );
            } else {
                $enddate = '0';
            }

            if ( (int)$membership_level->enddate < time() ) {
                return $video_submit->prop( 'submission_error', new WP_Error( 'membership_subscription_expired', __( 'Your Subcription has expired!' ) ) );
            }
        }
    }
}

// @TODO: Process screnshots
function haru_frontend_form_screen_video_upload( $post_id, $attachment_post_data = array() ) {
    // Make sure the right files were submitted
    if (
        empty( $_FILES )
        || ! isset( $_FILES['haru_video_screenshot'] )
        || isset( $_FILES['haru_video_screenshot']['error'] ) && 0 !== $_FILES['haru_video_screenshot']['error']
    ) {
        return;
    }
    // Filter out empty array values
    $files = array_filter( $_FILES['haru_video_screenshot'] );
    // Make sure files were submitted at all
    if ( empty( $files ) ) {
        return;
    }
    // Make sure to include the WordPress media uploader API if it's not (front-end)
    if ( ! function_exists( 'media_handle_upload' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );
    }
    // Upload the file and send back the attachment post ID
    return media_handle_upload( 'haru_video_screenshot', $post_id, $attachment_post_data );
}
