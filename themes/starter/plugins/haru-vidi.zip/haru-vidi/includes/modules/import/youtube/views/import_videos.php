<div class="video-central-import-youtube">

    <div class="video-central-import-wizard-form">

        <form method="get" action="" id="haru_vidi_load_feed_form">

            <?php wp_nonce_field( 'haru-vidi-import', 'haru_vidi_search_nonce'); ?>

            <input type="hidden" name="post_type" value="<?php echo $this->post_type;?>" />
            <input type="hidden" name="page" value="haru_vidi_import" />
            <input type="hidden" name="haru_vidi_source" value="youtube" />

            <table>
                <tr class="haru_vidi_feed">

                    <td valign="top">
                        <label for="haru_vidi_feed"><?php echo esc_html__( 'Feed type', 'haru-vidi' ); ?>:</label>
                        <span class="description"><?php echo esc_html__( 'Select the type of feed to load.', 'haru-vidi' ); ?></span>
                    </td>

                    <td>
                        <select name="haru_vidi_feed" id="haru_vidi_feed">
                            <option value="user" title="<?php echo esc_attr__( 'YouTube ID', 'haru-vidi' ); ?>" selected="selected"><?php echo esc_html__( 'User feed', 'haru-vidi' ); ?></option>
                            <option value="playlist" title="<?php echo esc_attr__( 'YouTube playlist ID', 'haru-vidi' ); ?>"><?php echo esc_html__( 'Playlist feed', 'haru-vidi' ); ?></option>
                            <option value="query" title="<?php echo esc_attr__( 'Search query', 'haru-vidi' ); ?>" ><?php echo esc_html__( 'Search query feed', 'haru-vidi' ); ?></option>
                            <option value="channel" title="<?php echo esc_attr__( 'Channel query', 'haru-vidi' ); ?>" ><?php echo esc_html__( 'Channel uploads feed', 'haru-vidi' ); ?></option>
                        </select>
                    </td>

                </tr>

                <tr class="haru_vidi_results">
                    <td valign="top">
                        <label for="haru_vidi_results"><?php echo esc_html__( 'Number of videos to retrieve', 'haru-vidi'); ?>:</label>
                        <span class="description"><?php echo esc_html__( 'Enter any number of results you want to retrieve. Results will be paginated. Youtube allows a maximum of 1000 per request.', 'haru-vidi' ); ?></span>
                    </td>
                    <td>
                        <input type="text" name="haru_vidi_results" id="haru_vidi_results" value="50" size="2" />
                    </td>
                </tr>

                <tr class="haru_vidi_duration">
                    <td valign="top"><label for="haru_vidi_duration"><?php echo esc_html__( 'Video duration', 'haru-vidi' ); ?>:</label></td>
                    <td>
                        <select name="haru_vidi_duration" id="haru_vidi_duration">
                            <option value=""><?php echo esc_html__( 'Any', 'haru-vidi' ); ?></option>
                            <option value="short"><?php echo esc_html__( 'Short (under 4min.)', 'haru-vidi' );?></option>
                            <option value="medium"><?php echo esc_html__( 'Medium (between 4 and 20min.)', 'haru-vidi' ); ?></option>
                            <option value="long"><?php echo esc_html__( 'Long (over 20min.)', 'haru-vidi'); ?></option>
                        </select>
                    </td>
                </tr>

                <tr class="haru_vidi_query">
                    <td valign="top">
                        <label for="haru_vidi_query"><?php echo esc_html__( 'Search by', 'haru-vidi' ); ?>:</label>
                        <span class="description"><?php echo esc_html__( 'Enter playlist ID, user ID or search query to use.', 'haru-vidi' ); ?></span>
                    </td>
                    <td>
                        <input type="text" name="haru_vidi_query" id="haru_vidi_query" value="" />
                    </td>
                </tr>

                <tr class="haru_vidi_order">
                    <td valign="top"><label for="haru_vidi_order"><?php echo esc_html__( 'Order by', 'haru-vidi' ); ?>:</label></td>
                    <td>
                        <select name="haru_vidi_order" id="haru_vidi_order">
                            <option value="date"><?php echo esc_html__( 'Date of publishing', 'haru-vidi' ); ?></option>
                            <option value="viewCount"><?php echo esc_html__( 'Number of views', 'haru-vidi' ); ?></option>

                            <option value="position"><?php echo esc_html__( 'Position in playlist', 'haru-vidi' ); ?></option>
                            <option value="commentCount"><?php echo esc_html__( 'Number of comments', 'haru-vidi' ); ?></option>
                            <option value="duration"><?php echo esc_html__( 'Duration (longest to shortest)', 'haru-vidi' ); ?></option>
                            <option value="reversedPosition"><?php echo esc_html__( 'Reversed position in playlist', 'haru-vidi' ); ?></option>
                            <option value="title"><?php echo esc_html__( 'Video title', 'haru-vidi' ); ?></option>

                            <option value="relevance" disabled="disabled"><?php echo esc_html__( 'Search relevance', 'haru-vidi'); ?></option>
                            <option value="rating" disabled="disabled"><?php echo esc_html__( 'Rating', 'haru-vidi');?></option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td valign="top"><label for=""></label></td>
                    <td></td>
                </tr>
            </table>

            <?php submit_button( esc_html__( 'Load video feed', 'haru-vidi' ), 'ajax-submit-params button-primary' ); ?>

        </form>

    </div>

</div>
