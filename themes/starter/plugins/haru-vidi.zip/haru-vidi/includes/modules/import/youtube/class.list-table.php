<?php
/**
 * List imported videos.
 */
class Haru_Vidi_Youtube_Importer_ListTable extends WP_List_Table {
    /**
     * The current list of items.
     *
     * @since 1.2.0
     *
     * @var array
     */
    public $items;

    /**
     * Feed error.
     *
     * @since 1.2.0
     *
     * @var bool
     */
    private $feed_errors = false;

    /**
     * Total items in feed.
     *
     * @since 1.2.0
     *
     * @var int
     */
    private $total_items = 0;

    /**
     * Next page token.
     *
     * @since 1.2.0
     *
     * @var string
     */
    private $next_token = '';

    /**
     * Previous page token.
     *
     * @since 1.2.0
     *
     * @var string
     */
    private $prev_token = '';

    /**
     * Constructor. Hooks all interactions to initialize the class.
     *
     * @since 1.0.0
     */
    public function __construct( $args = array() ) {
        parent::__construct(array(
            'singular'  => 'haru_video',
            'plural'    => 'haru_videos',
            'screen'    => isset( $args['screen'] ) ? $args['screen'] : null,
        ));
    }

    /**
     * Default column.
     *
     * @param array  $item
     * @param string $column
     *
     * @since 1.0.0
     */
    public function column_default( $item, $column ) {
        if ( array_key_exists( $column, $item ) ) {
            return $item[ $column ];
        } else {
            return '<span style="color:red">' . sprintf(__('Column <em>%s</em> was not found.', 'haru-vidi'), $column ) . '</span>';
        }
    }

    /**
     * Checkbox column.
     *
     * @param array $item
     *
     * @since 1.0.0
     */
    public function column_cb($item) {
        $output = sprintf('<input type="checkbox" name="haru_vidi_import[]" value="%1$s" id="haru_vidi_%1$s" />', $item['video_id']);

        return $output;
    }

    /**
     * Title column.
     *
     * @param array $item
     *
     * @since 1.0.0
     */
    public function column_title($item) {
        $label = sprintf('<label for="haru_vidi_%1$s" class="haru_vidi_label">%2$s</label>', $item['video_id'], $item['title']);

        // row actions
        $actions = array(
            'view' => sprintf('<a href="http://www.youtube.com/watch?v=%1$s" target="_haru_vidi_youtube_open">%2$s</a>', $item['video_id'], __('View on YouTube', 'haru-vidi')),
        );

        return sprintf('%1$s %2$s',
            $label,
            $this->row_actions($actions)
        );
    }

    /**
     * Column for video duration.
     *
     * @param array $item
     *
     * @since 1.0.0
     */
    public function column_duration($item) {
        return haru_vidi_human_time( $item['duration'] );
    }

    /**
     * Rating column.
     *
     * @param array $item
     *
     * @since 1.0.0
     */
    public function column_rating($item) {
        if ( 0 == $item['stats']['rating_count'] ) {
            return '-';
        }

        return number_format($item['stats']['rating'], 2) . sprintf(__(' (%d votes)', 'haru-vidi'), $item['stats']['rating_count']);
    }

    /**
     * Views column.
     *
     * @param array $item
     *
     * @since 1.0.0
     */
    public function column_views($item) {
        if ( 0 == $item['stats']['views'] ) {
            return '-';
        }

        return number_format( $item['stats']['views'], 0, '.', ',' );
    }

    /**
     * Date when the video was published.
     *
     * @param array $item
     */
    public function column_date($item) {
        $time = strtotime($item['published']);

        return date('M dS, Y @ H:i:s', $time);
    }

    /**
     * (non-PHPdoc).
     *
     * @see WP_List_Table::get_bulk_actions()
     */
    public function get_bulk_actions() {
        $actions = array(
            /*'import' => __('Import', 'haru-vidi')*/
        );

        return $actions;
    }

    /**
     * Returns the columns of the table as specified.
     */
    public function get_columns() {
        $columns = array(
            'cb'            => '<input type="checkbox" />',
            'title'         => __('Title', 'haru-vidi'),
            'category'      => __('Category', 'haru-vidi'),
            'video_id'      => __('Video ID', 'haru-vidi'),
            'duration'      => __('Duration', 'haru-vidi'),
            'rating'        => __('Rating', 'haru-vidi'),
            'views'         => __('Views', 'haru-vidi'),
            'date'          => __('Date', 'haru-vidi'),
        );

        return $columns;
    }

    public function extra_tablenav($which) {
        $suffix = 'top' == $which ? '_top' : '2';

        $selected = false;

        if (isset($_GET['cat'])) {
            $selected = $_GET['cat'];
        }

        $args = array(
            'show_count' => true,
            'hide_empty' => 0,
            'taxonomy' => haru_vidi_get_video_category_tax_id(),
            'name' => 'cat'.$suffix,
            'id' => 'haru_vidi_categories'.$suffix,
            'selected' => $selected,
            'hide_if_empty' => true,
            'echo' => false,
            'orderby' => 'NAME',
        );

        if (haru_vidi_import_categories()) {
            $args['show_option_all'] = __('Create categories from YouTube', 'haru-vidi');
        } else {
            $args['show_option_all'] = __('Select category (optional)', 'haru-vidi');
        }

        // get dropdown output
        $category_select = wp_dropdown_categories($args);

        ?>
        <select name="action<?php echo esc_attr( $suffix );
        ?>" id="action_<?php echo esc_attr( $which );
        ?>">
            <option value="-1"><?php _e('Bulk actions', 'haru-vidi');
        ?></option>
            <option value="import" selected="selected"><?php _e('Import', 'haru-vidi');
        ?></option>
        </select>

        <?php if ($category_select): ?>
            <label for="haru_vidi_categories<?php echo esc_attr( $suffix );
        ?>"><?php _e('Import into category', 'haru-vidi');
        ?> :</label>
            <?php echo $category_select;
        ?>
        <?php endif;
        ?>

        <?php submit_button( __( 'Apply', 'haru-vidi'), 'action', false, false, array('id' => 'doaction'. esc_attr( $suffix ) ) );
    }

    /**
     * (non-PHPdoc).
     *
     * @see WP_List_Table::prepare_items()
     */
    public function prepare_items() {
        $per_page = haru_vidi_import_results_per_page();
        $token = isset($_GET['token']) ? $_GET['token'] : '';

        switch ($_GET['haru_vidi_feed']) {
            case 'user':
            case 'playlist':
            case 'channel':
                $args = array(
                    'type'                  => 'manual',
                    'query'                 => $_GET['haru_vidi_query'],
                    'page_token'            => $token,
                    'include_categories'    => true,
                    'playlist_type'         => $_GET['haru_vidi_feed'],
                );

                $q = haru_vidi_youtube_api_get_list($args);

                $videos = $q['videos'];
                $list_stats = $q['page_info'];
            break;
            // perform a search query
            case 'query':
                $args = array(
                    'query'         => $_GET['haru_vidi_query'],
                    'page_token'    => $token,
                    'order'         => $_GET['haru_vidi_order'],
                    'duration'      => $_GET['haru_vidi_duration'],
                );
                $q = haru_vidi_youtube_api_search_videos($args);
                $videos = $q['videos'];
                $list_stats = $q['page_info'];

            break;
        }

        $videos = $q['videos'];
        $list_stats = $q['page_info'];

        if ( is_wp_error($videos) ) {
            $this->feed_errors = $videos;
            $videos = array();
        }

        $this->items        = $videos;
        $this->total_items  = $list_stats['total_results'];
        $this->next_token   = $list_stats['next_page'];
        $this->prev_token   = $list_stats['prev_page'];

        $this->set_pagination_args(array(
            'total_items'   => $this->total_items,
            'per_page'      => $per_page,
            'total_pages'   => ceil($this->total_items / $per_page),
        ));
    }

    /**
     * Displays a message if playlist is empty.
     *
     * @since 1.2.0
     */
    public function no_items() {
        echo esc_html__( 'YouTube feed is empty.', 'haru-vidi' );

        if ( is_wp_error( $this->feed_errors ) ) {
            echo '<br />';
            printf(__(' <strong>API error (code: %s)</strong>: %s', 'haru-vidi'), $this->feed_errors->get_error_code(), $this->feed_errors->get_error_message());
        }
    }

    /**
     * Display pagination.
     *
     * @since 1.2.0
     */
    protected function pagination($which) {
        $current_url    = set_url_scheme( 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] );
        $current_url    = remove_query_arg( array( 'hotkeys_highlight_last', 'hotkeys_highlight_first' ), $current_url );
        $disable_first  = empty($this->prev_token) ? ' disabled' : false;
        $disable_last   = empty($this->next_token) ? ' disabled' : false;

        $prev_page = sprintf("<a class='%s' title='%s' href='%s'>%s</a>",
            'prev-page' . $disable_first,
            esc_attr__( 'Go to the previous page', 'haru-vidi' ),
            esc_url( add_query_arg( 'token', $this->prev_token, $current_url ) ),
            '&lsaquo;'
        );

        ?>
        <div class="tablenav-pages">
            <span class="displaying-num"><?php printf(_n('1 item', '%s items', $this->total_items), number_format_i18n($this->total_items)); ?></span>
            <span class="pagination-links">
                <?php
                    // prev page
                    printf("<a class='%s' title='%s' href='%s'>%s</a>",
                        'prev-page' . $disable_first,
                        esc_attr__( 'Go to the previous page', 'haru-vidi' ),
                        esc_url( add_query_arg( 'token', $this->prev_token, $current_url ) ),
                        '&lsaquo;'
                    );

                    // next page
                    printf("<a class='%s' title='%s' href='%s'>%s</a>",
                        'prev-page' . $disable_last,
                        esc_attr__( 'Go to the next page', 'haru-vidi' ),
                        esc_url( add_query_arg('token', $this->next_token, $current_url) ),
                        '&rsaquo;'
                    );
                ?>
            </span>
        </div>

        <?php

    }
}
