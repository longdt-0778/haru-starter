<?php

/**
 * @package    HaruTheme/Haru Vidi
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
*/
class Haru_Vidi_Importer_Wizard {
    /**
     * Constructor. Hooks all interactions to initialize the class.
     *
     * @since 1.0.4
     */
    public function __construct() {
        // if ( ! haru_vidi_allow_video_imports() ) {
        //     return;
        // }

        $this->post_type = haru_vidi_get_video_post_type();

        // add extra menu pages
        add_action('admin_menu', array($this, 'menu_pages'), 1);
    }

    /**
     * Add subpages on our custom post type.
     *
     * @since 1.0.0
     *
     * @uses register_taxonomy() To register the taxonomy
     */
    public function menu_pages() {
        $video_import = add_submenu_page( 'edit.php?post_type=' . $this->post_type, esc_html__( 'Import videos', 'haru-vidi' ), esc_html__( 'Import videos', 'haru-vidi' ), 'edit_posts', 'haru_vidi_import', array( $this, 'import_source_tabs' ) );

        add_action( 'load-' . $video_import, array( $this, 'import_onload' ) );
    }

    /**
     * Output video importing page.
     *
     * @since 1.0.0
     */
    public function import_source_tabs() {
        $data_step_current = 1;
        $current = 'step1';

        if ( isset( $_REQUEST['haru_vidi_search_nonce'] ) ) {
            $data_step_current = 3;
            $current = 'step3';
        }

        ?>
        <div class="wizard-wrap" data-step="<?php echo esc_attr( $data_step_current ); ?>">
            <div class="wizard-container">

                <h1><?php echo esc_html__( 'Video Import Wizard', 'haru-vidi' ); ?></h1>

                <div class="progress_bar">
                    <hr class="all_steps">
                    <hr class="current_steps">

                    <div class="step 
                        <?php if ( $current == 'step2' || $current == 'step3' || $current == 'step4' ) {
                            echo 'complete';
                        } ?> 
                        <?php if ( $current == 'step1' ) {
                            echo 'current';
                        } ?>" 
                        id="step1" data-step="1">
                    <?php echo esc_html__( 'Select Source', 'haru-vidi' ); ?>
                    </div>

                    <div class="step 
                        <?php if ( $current == 'step2' || $current == 'step3' ) {
                            echo 'complete';
                        } ?> 
                        <?php if ( $current == 'step2' ) {
                            echo 'current';
                        } ?>" 
                        id="step2" data-step="2">
                        <?php echo esc_html__( 'Set Parameters', 'haru-vidi' ); ?>
                    </div>

                    <div class="step 
                        <?php if ( $current == 'step4' ) {
                            echo 'complete';
                        } ?> 
                        <?php if ( $current == 'step3' ) {
                            echo 'current';
                        } ?>" 
                        id="step3" data-step="3">
                        <?php echo esc_html__( 'Select Videos & Import', 'haru-vidi' ); ?>
                    </div>

                    <div class="step 
                        <?php if ( $current == 'step4' ) {
                            echo 'current';
                        } ?>" 
                        id="step4" data-step="4">
                        <?php echo esc_html__( 'Done', 'haru-vidi' ); ?>
                    </div>
                </div>

                <div id="blocks">
                    <div class="block" id="block1" <?php if ( $current == 'step1' ) { echo 'style="left: 0%;"'; } ?> >
                        <div class="wrap haru-vidi-import-source-tab">
                            <h2><?php echo esc_html__( 'Select Source', 'haru-vidi' ); ?></h2>
                            <div class="haru-vidi-import-source-tab">
                                <?php do_action( 'haru_vidi_import_source_tab' ); ?>
                            </div>

                            <br />
                            <a onclick="window.Haru_Vidi_Import.Wizard_Step_Process(1, 2)" class="button"><?php echo esc_html__( 'Start', 'haru-vidi' ); ?></a>
                        </div>
                    </div>
                    <div class="block" id="block2">
                        <div class="wrap haru-vidi-import-parameters">
                            <div class="haru-vidi-import-parameters-description">
                                <h2><?php echo esc_html__( 'Set Parameters', 'haru-vidi' ); ?></h2>
                                <p class="description">
                                    <?php echo esc_html__( 'Enter the search criteria and submit.', 'haru-vidi' ); ?>
                                </p>
                            </div>
                             <div id="haru-vidi-import-parameters">
                                 <?php do_action( 'haru_vidi_import_parameters'); ?>
                             </div>
                        </div>
                    </div>

                    <div class="block" id="block3">
                        <div class="wrap haru-vidi-import-table">
                            <div class="haru-vidi-import-table-description">
                                <h2 class="haru-vidi-ajax-response">
                                    <span class="haru-vidi-ajax-response-task"><?php echo esc_html__( 'Select Videos to Import', 'haru-vidi' ); ?></span><span class="sep">: </span>
                                    <span class="haru-vidi-ajax-response-progress"></span>
                                </h2>
                            </div>

                             <div id="haru-vidi-import-table">
                                 <?php do_action( 'haru_vidi_import_table'); ?>
                             </div>

                            <a onclick="window.Haru_Vidi_Import.Wizard_Step_Process(3, 2, 'desc')" class="button"><?php echo esc_html__( 'Go Back', 'haru-vidi' ); ?></a>
                         </div>
                    </div>

                    <div class="block" id="block4">
                        <div class="wrap haru-vidi-import-done">
                            <h2><?php echo esc_html__( 'Done', 'haru-vidi' ); ?></h2>
                            <div id="haru-vidi-import-done"><?php do_action( 'video_central_import_complete' ); ?></div>
                            <br />
                            <a onclick="window.Haru_Vidi_Import.Wizard_Step_Process(4, 1, 'restart')" class="button"><?php echo esc_html__( 'Start Over', 'haru-vidi' ); ?></a>
                            <a href="<?php echo admin_url( 'edit.php?post_type=' . haru_vidi_get_video_post_type() ); ?>" class="button"><?php echo esc_html__( 'Go to Videos List', 'haru-vidi' ); ?></a>
                        </div>
                    </div>

                </div>
                <br class="clear" />

            </div>

        </div>

        <div class="import-global-loading"></div>
        <div class="import-global-message"></div>

        <?php

    }

    /**
     * On video import page load, perform actions.
     *
     * @since 1.0.0
     */
    public function import_onload() {
        do_action('video_central_import_onload');
    }
}

function haru_vidi_get_video_post_type() {
    return 'haru_video';
}


$video_importer_wizard = new Haru_Vidi_Importer_Wizard();
?>
